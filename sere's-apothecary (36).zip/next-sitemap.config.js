module.exports = {
  siteUrl: process.env.NEXT_PUBLIC_SITE_URL || 'https://seresapothecary.com',
  generateRobotsTxt: true,
}
