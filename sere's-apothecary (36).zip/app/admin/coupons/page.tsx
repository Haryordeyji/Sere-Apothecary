'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '@/convex/_generated/api'
import { Plus, Lock, ChevronDown } from 'lucide-react'

const formatDate = (ts?: number) =>
  ts ? new Date(ts).toLocaleDateString('en-NG', {
    day: 'numeric', month: 'short', year: 'numeric',
  }) : 'N/A'

export default function AdminCouponsPage() {
  const [role, setRole] = useState<'master' | 'sub' | null>(null)
  const [token, setToken] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/admin/session').then(res => res.json()).then(s => {
      setRole(s?.role || null)
      setToken(s?.token || null)
    }).catch(()=>{})
  }, [])

  const couponsArgs = token ? { token: token } : "skip" as any
  const coupons = useQuery(api.coupons.listCoupons, couponsArgs)
  const createCoupon = useMutation(api.coupons.createCoupon)
  const toggleCoupon = useMutation(api.coupons.toggleCoupon)

  const [showForm, setShowForm] = useState(false)
  const [code, setCode] = useState('')
  const [discountPercent, setDiscountPercent] = useState('')
  const [createError, setCreateError] = useState('')
  const [saving, setSaving] = useState(false)
  const [toggling, setToggling] = useState<string | null>(null)

  if (role !== null && role !== 'master') {
    return (
      <div className="px-4 sm:px-6 py-8 max-w-lg mx-auto text-center">
        <div className="bg-cream border border-gold/10 p-12">
          <Lock size={32} className="text-brown/20 mx-auto mb-4" />
          <p className="font-display text-brown text-xl mb-2">Access Denied</p>
          <p className="font-body text-sm text-brown/50">
            Only the Master Admin can manage coupon codes.
          </p>
        </div>
      </div>
    )
  }

  const handleCreate = async () => {
    if (!code || !discountPercent) {
      setCreateError('Code and discount % are required.')
      return
    }
    const pct = Number(discountPercent)
    if (isNaN(pct) || pct < 1 || pct > 100) {
      setCreateError('Discount must be between 1 and 100.')
      return
    }
    setSaving(true)
    setCreateError('')
    try {
      if (!token) {
        setCreateError(
          'Session expired. Please log in again.'
        )
        return
      }
      await createCoupon({ 
        code: code.toUpperCase(), 
        discountPercent: pct,
        token: token 
      })
      setCode('')
      setDiscountPercent('')
      setShowForm(false)
    } catch (e: any) {
      setCreateError(e.message || 'Failed to create coupon.')
    } finally {
      setSaving(false)
    }
  }

  const handleToggle = async (id: string) => {
    setToggling(id)
    try { 
      if (!token) return
      await toggleCoupon({ token: token, id: id as any }) 
    }
    finally { setToggling(null) }
  }

  return (
    <div className="px-4 sm:px-6 py-8 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-2">
        <h1 className="font-display text-brown text-2xl">Coupon Codes</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="btn-gold flex items-center gap-2 py-2 px-4"
        >
          <Plus size={16} />
          New Coupon
          <ChevronDown size={14} className={showForm ? 'rotate-180' : ''} />
        </button>
      </div>
      <p className="font-body text-sm text-brown/40 mb-6">
        All coupons are manually created. No auto-generation.
      </p>

      {/* Create form */}
      {showForm && (
        <div className="bg-cream border border-gold/20 p-6 mb-6">
          <p className="font-accent text-xs tracking-widest uppercase text-gold/60 mb-4">
            Create Coupon
          </p>
          <div className="grid sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="font-body text-xs text-brown/60 uppercase tracking-widest mb-1 block">
                Coupon Code
              </label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="e.g. SERE10"
                className="w-full border border-brown/20 px-4 py-2.5 font-accent text-brown tracking-widest text-sm focus:outline-none focus:border-gold bg-white uppercase"
              />
            </div>
            <div>
              <label className="font-body text-xs text-brown/60 uppercase tracking-widest mb-1 block">
                Discount %
              </label>
              <input
                type="number"
                value={discountPercent}
                onChange={(e) => setDiscountPercent(e.target.value)}
                placeholder="e.g. 10"
                min={1}
                max={100}
                className="w-full border border-brown/20 px-4 py-2.5 font-body text-brown text-sm focus:outline-none focus:border-gold bg-white"
              />
            </div>
          </div>
          {createError && (
            <p className="text-red-500 text-xs mb-3">{createError}</p>
          )}
          <div className="flex gap-3">
            <button
              onClick={handleCreate}
              disabled={saving}
              className="btn-gold py-2 px-6 disabled:opacity-50"
            >
              {saving ? 'Creating...' : 'Create Coupon'}
            </button>
            <button
              onClick={() => { setShowForm(false); setCreateError('') }}
              className="btn-outline-gold py-2 px-6"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Coupons table */}
      {!coupons ? (
        <div className="space-y-2">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-14 bg-cream animate-pulse" />
          ))}
        </div>
      ) : coupons.length === 0 ? (
        <div className="bg-cream border border-gold/10 p-12 text-center">
          <p className="font-display text-brown/40 text-xl">No coupons yet</p>
          <button onClick={() => setShowForm(true)} className="btn-gold mt-4 py-2 px-6">
            Create your first coupon
          </button>
        </div>
      ) : (
        <div className="bg-cream border border-gold/10 overflow-hidden">
          <table className="w-full font-body text-sm">
            <thead>
              <tr className="border-b border-gold/10 bg-cream-warm">
                {['Code', 'Discount', 'Status', 'Created', 'Action'].map((h) => (
                  <th key={h} className="text-left px-4 py-3 text-brown/50 font-normal text-xs tracking-widest uppercase">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {coupons.map((coupon) => (
                <tr key={coupon._id} className="border-b border-gold/5 hover:bg-cream-warm transition-colors">
                  <td className="px-4 py-3">
                    <span className="font-accent text-gold tracking-widest text-sm">
                      {coupon.code}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-brown font-body">
                    {coupon.discountPercent}% off
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1.5">
                      <div className={`w-1.5 h-1.5 rounded-full ${coupon.isActive ? 'bg-green-500' : 'bg-brown/20'}`} />
                      <span className={`text-xs font-body ${coupon.isActive ? 'text-green-600' : 'text-brown/40'}`}>
                        {coupon.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-brown/40 text-xs">
                    {formatDate(coupon.createdAt)}
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => handleToggle(coupon._id)}
                      disabled={toggling === coupon._id}
                      className={`font-accent text-[10px] tracking-widest uppercase px-3 py-1.5 border transition-colors disabled:opacity-40 ${
                        coupon.isActive
                          ? 'border-red-300 text-red-500 hover:bg-red-50'
                          : 'border-green-300 text-green-600 hover:bg-green-50'
                      }`}
                    >
                      {toggling === coupon._id
                        ? '...'
                        : coupon.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}