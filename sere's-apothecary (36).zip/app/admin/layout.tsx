'use client'

import { useEffect, useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, Package, ShoppingBag,
  Star, Users, Tag, LogOut, Menu, X,
} from 'lucide-react'

interface AdminSession {
  email: string
  role: 'master' | 'sub'
  token: string
}

const navItems = [
  { label: 'Dashboard', href: '/admin/dashboard', icon: LayoutDashboard, masterOnly: false },
  { label: 'Products', href: '/admin/products', icon: Package, masterOnly: false },
  { label: 'Orders', href: '/admin/orders', icon: ShoppingBag, masterOnly: false },
  { label: 'Reviews', href: '/admin/reviews', icon: Star, masterOnly: false },
  { label: 'Team', href: '/admin/team', icon: Users, masterOnly: true },
  { label: 'Coupons', href: '/admin/coupons', icon: Tag, masterOnly: true },
]

function Sidebar({
  session,
  pathname,
  onLogout,
  onClose,
}: {
  session: AdminSession
  pathname: string
  onLogout: () => void
  onClose?: () => void
}) {
  return (
    <div className="flex flex-col h-full bg-brown-deep">
      <div className="px-6 py-6 border-b border-gold/10">
        <p className="font-accent text-gold tracking-widest text-xs uppercase">
          Sere&apos;s
        </p>
        <p className="font-body text-cream/30 text-xs mt-1">Admin Portal</p>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems
          .filter((item) => !item.masterOnly || session.role === 'master')
          .map((item) => {
            const isActive = pathname.startsWith(item.href)
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onClose}
                className={`flex items-center gap-3 px-4 py-2.5 font-body text-sm transition-colors ${
                  isActive
                    ? 'bg-gold/10 text-gold border-l-2 border-gold'
                    : 'text-cream/50 hover:text-cream hover:bg-white/5'
                }`}
              >
                <item.icon size={16} />
                {item.label}
              </Link>
            )
          })}
      </nav>

      <div className="px-6 py-4 border-t border-gold/10">
        <p className="font-accent text-[10px] tracking-widest text-gold/50 uppercase mb-1">
          {session.role}
        </p>
        <p className="font-body text-xs text-cream/30 truncate mb-3">
          {session.email}
        </p>
        <button
          onClick={onLogout}
          className="flex items-center gap-2 font-body text-xs text-cream/30 hover:text-red-400 transition-colors"
        >
          <LogOut size={14} />
          Sign Out
        </button>
      </div>
    </div>
  )
}

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const pathname = usePathname()
  const [session, setSession] = useState<AdminSession | null>(null)
  const [checked, setChecked] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [mounted, setMounted] = useState(false)

  // Wait for client mount before touching localStorage
  useEffect(() => {
    setMounted(true)
  }, [])

  // Only read from API after component is mounted on client
  useEffect(() => {
    if (!mounted) return
    if (typeof window === 'undefined') return

    const loadSession = async () => {
      try {
        // Try cookie-based session first
        const res = await fetch('/api/admin/session')
        const data = await res.json()
        if (data?.token && data?.role && data?.email) {
          setSession(data)
          setChecked(true)
          return
        }
        
        // Fallback: check localStorage
        const stored = localStorage.getItem('admin_session')
        if (stored) {
          const parsed = JSON.parse(stored)
          if (parsed?.email && parsed?.role && parsed?.token) {
            // Migrate to cookie
            await fetch('/api/admin/session', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(parsed),
            })
            setSession(parsed)
            localStorage.removeItem('admin_session')
            setChecked(true)
            return
          }
        }
      } catch {}
      setChecked(true)
    }
    
    loadSession()
  }, [mounted])

  // Redirect to login if no valid session
  useEffect(() => {
    if (!checked) return
    if (!session && !pathname.includes('/admin/login')) {
      router.replace('/admin/login')
    }
  }, [checked, session, pathname, router])

  const handleLogout = () => {
    fetch('/api/admin/session', { method: 'DELETE' })
      .finally(() => {
        try {
          localStorage.removeItem('admin_session')
        } catch {}
        setSession(null)
        router.replace('/admin/login')
      })
  }

 // Show nothing on server — prevents hydration mismatch
  if (!mounted) {
    // If it's the login page, render it immediately without the dark screen
    if (pathname.includes('/admin/login')) {
      return <>{children}</>
    }
    return (
      <div className="min-h-screen bg-brown-deep" />
    )
  }
 // Show spinner while checking localStorage
  // But render login page immediately without waiting
  if (!checked) {
    if (pathname.includes('/admin/login')) {
      return <>{children}</>
    }
    return (
      <div className="min-h-screen bg-brown-deep flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin border-2 border-gold border-t-transparent rounded-full w-8 h-8" />
          <p className="font-accent text-gold/40 text-xs tracking-widest uppercase">
            Verifying access...
          </p>
        </div>
      </div>
    )
  }

 // No session — if on login page render it, otherwise spin while redirecting
  if (!session) {
    if (pathname.includes('/admin/login')) {
      return <>{children}</>
    }
    return (
      <div className="min-h-screen bg-brown-deep flex items-center justify-center">
        <div className="animate-spin border-2 border-gold border-t-transparent rounded-full w-8 h-8" />
      </div>
    )
  }

  // Valid session — render admin panel
  return (
    <div className="min-h-screen flex bg-cream-warm">
      {/* Desktop sidebar */}
      <div className="hidden lg:block fixed left-0 top-0 h-full w-60 z-30">
        <Sidebar
          session={session}
          pathname={pathname}
          onLogout={handleLogout}
        />
      </div>

      {/* Mobile header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-20 bg-brown border-b border-gold/20 px-4 py-3 flex items-center justify-between">
        <button
          onClick={() => setSidebarOpen(true)}
          className="text-cream hover:text-gold transition-colors"
        >
          <Menu size={20} />
        </button>
        <p className="font-accent text-gold tracking-widest text-sm uppercase">
          Admin
        </p>
        <span className="font-body text-xs text-gold/50 uppercase">
          {session.role}
        </span>
      </div>

      {/* Mobile sidebar overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-40 lg:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
            />
            <motion.div
              className="fixed left-0 top-0 h-full w-60 z-50 lg:hidden"
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
            >
              <div className="absolute top-4 right-4">
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="text-cream/40 hover:text-cream transition-colors"
                >
                  <X size={18} />
                </button>
              </div>
              <Sidebar
                session={session}
                pathname={pathname}
                onLogout={handleLogout}
                onClose={() => setSidebarOpen(false)}
              />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main content */}
      <div className="flex-1 lg:ml-60 min-h-screen pt-14 lg:pt-0">
        {children}
      </div>
    </div>
  )
}