'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '@/convex/_generated/api'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Pencil, Trash2, Eye, EyeOff, X } from 'lucide-react'
import Image from 'next/image'

interface ProductForm {
  name: string
  description: string
  price: string
  category: 'perfume' | 'skincare'
  imageUrl: string
  stock: string
  isActive: boolean
  isFeatured: boolean
}

const emptyForm: ProductForm = {
  name: '', description: '', price: '',
  category: 'perfume', imageUrl: '', stock: '', isActive: true, isFeatured: false,
}

const formatPrice = (n: number) =>
  `₦${n.toLocaleString('en-NG', { minimumFractionDigits: 2 })}`

export default function AdminProductsPage() {
  const [token, setToken] = useState<string | null>(null)
  
  useEffect(() => {
    fetch('/api/admin/session').then(res => res.json()).then(s => setToken(s?.token)).catch(()=>{})
  }, [])

  const products = useQuery(api.products.listProducts, {})
  const createProduct = useMutation(api.products.createProduct)
  const updateProduct = useMutation(api.products.updateProduct)
  const deleteProduct = useMutation(api.products.deleteProduct)

  const [showModal, setShowModal] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState<ProductForm>(emptyForm)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const openAdd = () => {
    setForm(emptyForm)
    setEditingId(null)
    setError('')
    setShowModal(true)
  }

  const openEdit = (p: any) => {
    setForm({
      name: p.name, description: p.description,
      price: String((p.priceKobo || 0) / 100), category: p.category,
      imageUrl: p.images?.[0] || '', stock: String(p.stock),
      isActive: p.isActive,
      isFeatured: p.isFeatured || false,
    })
    setEditingId(p._id)
    setError('')
    setShowModal(true)
  }

  const handleSave = async () => {
    if (!form.name || !form.price || !form.stock) {
      setError('Name, price and stock are required.')
      return
    }
    if (!token) {
      setError('Session expired. Please log in again.')
      return
    }
    setSaving(true)
    setError('')
    try {
      if (editingId) {
        await updateProduct({
          token,
          id: editingId as any,
          name: form.name,
          description: form.description,
          priceKobo: Math.round(Number(form.price) * 100),
          category: form.category as any,
          images: form.imageUrl ? [form.imageUrl] : [],
          stock: Number(form.stock),
          isActive: form.isActive,
          isFeatured: form.isFeatured,
          priceDisplay: `₦${Number(form.price).toLocaleString('en-NG', { minimumFractionDigits: 2 })}`,
        })
      } else {
        await createProduct({
          token,
          name: form.name,
          slug: form.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
          description: form.description,
          priceKobo: Math.round(Number(form.price) * 100),
          priceDisplay: `₦${Number(form.price).toLocaleString('en-NG', { minimumFractionDigits: 2 })}`,
          category: form.category as any,
          images: form.imageUrl ? [form.imageUrl] : ['https://i.pinimg.com/736x/e3/f0/41/e3f041b39ec6bbf69e0a772be88907fe.jpg'],
          stock: Number(form.stock),
          isActive: form.isActive,
          isFeatured: form.isFeatured,
        })
      }
      setShowModal(false)
    } catch (e: any) {
      setError(e.message || 'Failed to save product.')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string, name: string) => {
    if (!token) {
      alert('Session expired. Please refresh.')
      return
    }
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return
    try {
      await deleteProduct({ id: id as any, token })
    } catch (e: any) {
      alert(e.message || 'Failed to delete product.')
    }
  }

  const handleToggle = async (p: any) => {
    if (!token) return
    try {
      await updateProduct({ id: p._id, token, isActive: !p.isActive })
    } catch (e: any) {
      alert(e.message || 'Failed to update product.')
    }
  }

  return (
    <div className="px-4 sm:px-6 py-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="font-display text-brown text-2xl">Products</h1>
        <button onClick={openAdd} className="btn-gold flex items-center gap-2 py-2 px-4">
          <Plus size={16} /> Add Product
        </button>
      </div>

      {!products ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-16 bg-cream animate-pulse rounded" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="bg-cream border border-gold/10 p-12 text-center">
          <p className="font-display text-brown/40 text-xl">No products yet</p>
          <button onClick={openAdd} className="btn-gold mt-4 py-2 px-6">
            Add your first product
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto bg-cream border border-gold/10">
          <table className="w-full font-body text-sm">
            <thead>
              <tr className="border-b border-gold/10 bg-cream-warm">
                {['Image', 'Name', 'Category', 'Price', 'Stock', 'Status', 'Actions'].map((h) => (
                  <th key={h} className="text-left px-4 py-3 text-brown/50 font-normal text-xs tracking-widest uppercase">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {products.map((p) => {
                const safeImageUrl = p.images?.[0] || null;
                return (
                <tr key={p._id} className="border-b border-gold/5 hover:bg-cream-warm transition-colors">
                  <td className="px-4 py-3">
                    <div className="relative w-10 h-10 bg-cream-warm rounded overflow-hidden">
                      {safeImageUrl ? (
                        <Image
                          src={safeImageUrl}
                          alt={p.name} fill
                          sizes="40px"
                          className="object-cover"
                        />
                      ) : (
                        <div className="w-10 h-10 bg-cream-warm flex items-center justify-center text-brown/20 text-[9px]">
                          N/A
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-brown font-medium max-w-[200px] truncate">
                    {p.name}
                  </td>
                  <td className="px-4 py-3">
                    <span className="font-accent text-[10px] tracking-widest uppercase text-brown/60 bg-cream-warm px-2 py-1">
                      {p.category || 'product'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gold">
                    {p.priceKobo > 0 ? formatPrice(p.priceKobo / 100) : '—'}
                  </td>
                  <td className="px-4 py-3 text-brown">
                    <span className={p.stock === 0 ? 'text-red-500' : p.stock < 5 ? 'text-amber-600' : ''}>
                      {p.stock}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <button onClick={() => handleToggle(p)} className="flex items-center gap-1.5">
                      {p.isActive ? (
                        <><Eye size={14} className="text-green-500" /><span className="text-green-600 text-xs">Active</span></>
                      ) : (
                        <><EyeOff size={14} className="text-brown/30" /><span className="text-brown/30 text-xs">Hidden</span></>
                      )}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <button onClick={() => openEdit(p)} className="text-brown/40 hover:text-gold transition-colors">
                        <Pencil size={14} />
                      </button>
                      <button onClick={() => handleDelete(p._id, p.name)} className="text-brown/40 hover:text-red-500 transition-colors">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      <AnimatePresence>
        {showModal && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/50 z-50"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowModal(false)}
            />
            <motion.div
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            >
              <div className="bg-cream-warm w-full max-w-lg max-h-[90vh] overflow-y-auto p-8 relative"
                onClick={(e) => e.stopPropagation()}>
                <button onClick={() => setShowModal(false)}
                  className="absolute top-4 right-4 text-brown/40 hover:text-brown">
                  <X size={18} />
                </button>
                <h2 className="font-display text-brown text-xl mb-6">
                  {editingId ? 'Edit Product' : 'Add Product'}
                </h2>

                <div className="space-y-4">
                  {[
                    { label: 'Product Name', key: 'name', type: 'text', placeholder: 'e.g. Oud & Amber Elixir' },
                    { label: 'Image URL', key: 'imageUrl', type: 'text', placeholder: 'https://...' },
                    { label: 'Price (₦)', key: 'price', type: 'number', placeholder: '25000' },
                    { label: 'Stock Quantity', key: 'stock', type: 'number', placeholder: '10' },
                  ].map(({ label, key, type, placeholder }) => (
                    <div key={key}>
                      <label className="font-body text-xs text-brown/60 uppercase tracking-widest mb-1 block">{label}</label>
                      <input type={type} value={(form as any)[key]}
                        onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                        placeholder={placeholder}
                        className="w-full border border-brown/20 px-4 py-2.5 font-body text-brown text-sm focus:outline-none focus:border-gold bg-white"
                      />
                    </div>
                  ))}

                  <div>
                    <label className="font-body text-xs text-brown/60 uppercase tracking-widest mb-1 block">Description</label>
                    <textarea rows={3} value={form.description}
                      onChange={(e) => setForm({ ...form, description: e.target.value })}
                      className="w-full border border-brown/20 px-4 py-2.5 font-body text-brown text-sm focus:outline-none focus:border-gold bg-white"
                    />
                  </div>

                  <div>
                    <label className="font-body text-xs text-brown/60 uppercase tracking-widest mb-1 block">Category</label>
                    <select value={form.category}
                      onChange={(e) => setForm({ ...form, category: e.target.value as any })}
                      className="w-full border border-brown/20 px-4 py-2.5 font-body text-brown text-sm focus:outline-none focus:border-gold bg-white">
                      <option value="perfume">Perfume</option>
                      <option value="skincare">Skincare</option>
                    </select>
                  </div>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" checked={form.isActive}
                      onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                      className="accent-gold w-4 h-4"
                    />
                    <span className="font-body text-sm text-brown/70">Active (visible in store)</span>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" 
                      checked={form.isFeatured}
                      onChange={(e) => setForm({ 
                        ...form, isFeatured: e.target.checked 
                      })}
                      className="accent-gold w-4 h-4"
                    />
                    <span className="font-body text-sm text-brown/70">
                      Featured (show on homepage)
                    </span>
                  </label>
                </div>

                {error && <p className="text-red-500 text-xs mt-4">{error}</p>}

                <div className="flex gap-3 mt-6">
                  <button onClick={handleSave} disabled={saving} className="btn-gold flex-1 py-3 disabled:opacity-50">
                    {saving ? 'Saving...' : editingId ? 'Save Changes' : 'Add Product'}
                  </button>
                  <button onClick={() => setShowModal(false)} className="btn-outline-gold px-6 py-3">
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}