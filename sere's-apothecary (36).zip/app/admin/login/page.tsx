'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Eye, EyeOff, Lock } from 'lucide-react'
import { useMutation } from 'convex/react'
import { api } from '@/convex/_generated/api'
import Link from 'next/link'

export default function AdminLoginPage() {
  const router = useRouter()
  const loginMutation = useMutation(api.admins.loginAdmin)

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [attempts, setAttempts] = useState(0)
  const [lockedUntil, setLockedUntil] = useState(0)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    // If already logged in, go straight to dashboard
    fetch('/api/admin/session')
      .then(res => res.json())
      .then(parsed => {
        if (parsed?.email && parsed?.role && parsed?.token) {
          router.replace('/admin/dashboard')
        }
      })
      .catch(() => {})
  }, [router])

  const isLocked = mounted && lockedUntil > Date.now()
  const remainingSeconds = Math.ceil((lockedUntil - Date.now()) / 1000)

  const handleLogin = async () => {
    if (isLocked) return
    if (!email || !password) {
      setError('Please enter your email and password.')
      return
    }

    if (attempts >= 3) {
      const lockTime = Date.now() + 15 * 60 * 1000
      setLockedUntil(lockTime)
      setError('Too many failed attempts. Locked locally for 15 minutes.')
      return
    }

    setIsLoading(true)
    setError('')

    try {
      const result = await loginMutation({ email, password })

      if (result.token) {
        const session = {
          email: result.email,
          role: result.role,
          token: result.token,
        }
        
        await fetch('/api/admin/session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(session)
        });

        // Hard navigate to force full re-render of layout
        window.location.href = '/admin/dashboard'
      } else {
        setAttempts((prev) => prev + 1)
        setError('Invalid email or password. Please try again.')
        setIsLoading(false)
      }
    } catch (err: any) {
      console.error('Login error:', err)
      setAttempts((prev) => prev + 1)
      if (err.message && err.message.includes('locked')) {
        setError('Too many failed attempts. Account locked temporarily.')
      } else {
        setError('Invalid email or password. Please try again.')
      }
      setIsLoading(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleLogin()
  }

  return (
    <div className="min-h-screen bg-[#1A0F0A] flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-sm w-full"
      >
        {/* Brand header */}
        <div className="text-center mb-10">
          <p
            style={{ fontFamily: 'Georgia, serif' }}
            className="text-[#C9A84C] tracking-[0.25em] text-sm uppercase"
          >
            Sere&apos;s Apothecary
          </p>
          <div className="w-12 h-px bg-[#C9A84C]/30 mx-auto my-4" />
          <p className="text-[#F5F0E8]/30 text-xs tracking-widest uppercase">
            Admin Portal
          </p>
        </div>

        {/* Card */}
        <div
          style={{ backgroundColor: '#2C1810', border: '1px solid rgba(201,168,76,0.2)' }}
          className="p-8"
        >
          {/* Lock icon */}
          <div
            style={{ border: '1px solid rgba(201,168,76,0.3)' }}
            className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <Lock size={18} style={{ color: 'rgba(201,168,76,0.6)' }} />
          </div>

          {isLocked ? (
            <div
              style={{
                border: '1px solid rgba(239,68,68,0.3)',
                backgroundColor: 'rgba(239,68,68,0.1)',
              }}
              className="p-4 text-center rounded"
            >
              <p className="text-sm text-red-400 mb-1">
                Access temporarily locked.
              </p>
              <p className="text-xs text-red-400/70">
                Try again in {remainingSeconds} seconds.
              </p>
            </div>
          ) : (
            <>
              {/* Email field */}
              <div className="mb-4">
                <label className="block text-xs text-[#F5F0E8]/40 tracking-widest uppercase mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="admin@email.com"
                  style={{
                    backgroundColor: '#1A0F0A',
                    border: '1px solid rgba(201,168,76,0.2)',
                    color: '#F5F0E8',
                  }}
                  className="w-full px-4 py-3 text-sm focus:outline-none placeholder:text-[#F5F0E8]/20"
                />
              </div>

              {/* Password field */}
              <div className="mb-4 relative">
                <label className="block text-xs text-[#F5F0E8]/40 tracking-widest uppercase mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="••••••••"
                    style={{
                      backgroundColor: '#1A0F0A',
                      border: '1px solid rgba(201,168,76,0.2)',
                      color: '#F5F0E8',
                    }}
                    className="w-full px-4 py-3 pr-12 text-sm focus:outline-none placeholder:text-[#F5F0E8]/20"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 transition-colors"
                    style={{ color: 'rgba(245,240,232,0.3)' }}
                  >
                    {showPassword
                      ? <EyeOff size={16} />
                      : <Eye size={16} />
                    }
                  </button>
                </div>
              </div>

              {/* Error */}
              {error && (
                <p className="text-xs text-red-400 mb-3">{error}</p>
              )}

              {/* Attempts warning */}
              {attempts > 0 && attempts < 3 && (
                <p className="text-xs text-amber-400 mb-3">
                  {3 - attempts} attempt(s) remaining before lockout.
                </p>
              )}

              {/* LOGIN BUTTON — inline styles to guarantee visibility */}
              <button
                onClick={handleLogin}
                disabled={isLoading}
                style={{
                  backgroundColor: isLoading
                    ? 'rgba(201,168,76,0.5)'
                    : '#C9A84C',
                  color: '#2C1810',
                  width: '100%',
                  padding: '12px 24px',
                  marginTop: '8px',
                  fontFamily: 'Georgia, serif',
                  letterSpacing: '0.2em',
                  textTransform: 'uppercase',
                  fontSize: '13px',
                  fontWeight: '600',
                  border: 'none',
                  cursor: isLoading ? 'not-allowed' : 'pointer',
                  display: 'block',
                  transition: 'background-color 0.2s ease',
                }}
              >
                {isLoading ? 'Verifying...' : 'Access Portal'}
              </button>
            </>
          )}
        </div>

        {/* Back link */}
        <div className="text-center mt-6">
          <Link
            href="/"
            style={{ color: 'rgba(245,240,232,0.2)' }}
            className="text-xs hover:opacity-50 transition-opacity"
          >
            ← Return to store
          </Link>
        </div>
      </motion.div>
    </div>
  )
}