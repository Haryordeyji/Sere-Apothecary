'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '@/convex/_generated/api'
import { Star, Check, Trash2 } from 'lucide-react'

const formatDate = (ts?: number) =>
  ts ? new Date(ts).toLocaleDateString('en-NG', {
    day: 'numeric', month: 'short', year: 'numeric',
  }) : 'N/A'

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          size={12}
          className={s <= rating ? 'text-gold fill-gold' : 'text-brown/20'}
        />
      ))}
    </div>
  )
}

export default function AdminReviewsPage() {
  const [token, setToken] = useState<string | null>(null)
  useEffect(() => {
    fetch('/api/admin/session').then(res => res.json()).then(s => setToken(s?.token)).catch(()=>{})
  }, [])
  
  const reviews = useQuery(
    api.reviews.listAllReviews,
    token ? { token } : 'skip'
  )
  const updateReviewStatus = useMutation(api.reviews.updateReviewStatus)
  const deleteReview = useMutation(api.reviews.deleteReview)
  const [tab, setTab] = useState<'pending' | 'approved'>('pending')
  const [acting, setActing] = useState<string | null>(null)

  const filtered = reviews?.filter((r) =>
    tab === 'pending' ? r.status === 'pending' : r.status === 'approved'
  )

  const handleApprove = async (id: string) => {
    if (!token) return
    setActing(id)
    try { await updateReviewStatus({ id: id as any, status: 'approved', token }) }
    finally { setActing(null) }
  }

  const handleDelete = async (id: string) => {
    if (!token) return
    if (!confirm('Delete this review? This cannot be undone.')) return
    setActing(id)
    try { await deleteReview({ id: id as any, token }) }
    finally { setActing(null) }
  }

  return (
    <div className="px-4 sm:px-6 py-8 max-w-4xl mx-auto">
      <h1 className="font-display text-brown text-2xl mb-6">Reviews</h1>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-gold/10">
        {(['pending', 'approved'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`pb-3 px-1 font-accent text-xs tracking-widest uppercase transition-colors border-b-2 -mb-px ${
              tab === t
                ? 'border-gold text-gold'
                : 'border-transparent text-brown/40 hover:text-brown'
            }`}
          >
            {t}{' '}
            <span className="ml-1 text-[10px]">
              ({reviews?.filter((r) =>
                t === 'pending' ? r.status === 'pending' : r.status === 'approved'
              ).length ?? 0})
            </span>
          </button>
        ))}
      </div>

      {!reviews ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-24 bg-cream animate-pulse" />
          ))}
        </div>
      ) : filtered?.length === 0 ? (
        <div className="bg-cream border border-gold/10 p-12 text-center">
          <p className="font-display text-brown/40 text-xl">
            No {tab} reviews
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered?.map((review) => (
            <div
              key={review._id}
              className="bg-cream border border-gold/10 p-5"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-display text-brown text-base">
                      {review.reviewerName}
                    </span>
                    <StarRating rating={review.rating} />
                    <span className="font-body text-xs text-brown/30">
                      {formatDate(review.createdAt)}
                    </span>
                  </div>
                  <p className="font-body text-sm text-brown/70 leading-relaxed">
                    {review.body}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {tab === 'pending' && (
                    <button
                      onClick={() => handleApprove(review._id)}
                      disabled={acting === review._id}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 border border-green-200 text-green-700 font-body text-xs hover:bg-green-100 transition-colors disabled:opacity-40"
                    >
                      <Check size={12} />
                      Approve
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(review._id)}
                    disabled={acting === review._id}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 border border-red-200 text-red-600 font-body text-xs hover:bg-red-100 transition-colors disabled:opacity-40"
                  >
                    <Trash2 size={12} />
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}