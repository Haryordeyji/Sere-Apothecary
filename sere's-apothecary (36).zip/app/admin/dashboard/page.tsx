'use client'

import { useQuery } from 'convex/react'
import { useState, useEffect } from 'react'
import { api } from '@/convex/_generated/api'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell,
} from 'recharts'
import { TrendingUp, ShoppingBag, Package, Clock } from 'lucide-react'

const PIE_COLORS = ['#C9A84C', '#2C1810', '#E2C97E', '#A8862F', '#F5F0E8', '#1A0F0A']

const formatPrice = (amount: number) =>
  `₦${amount.toLocaleString('en-NG', { minimumFractionDigits: 0 })}`

function StatCard({
  label, value, icon: Icon, accent,
}: {
  label: string
  value: string | number
  icon: React.ElementType
  accent?: boolean
}) {
  return (
    <div className="bg-cream border border-gold/10 p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="font-body text-xs text-brown/50 uppercase tracking-widest mb-2">
            {label}
          </p>
          <p className={`font-display text-2xl ${accent ? 'text-amber-600' : 'text-brown'}`}>
            {value}
          </p>
        </div>
        <div className="bg-gold/10 p-2 rounded">
          <Icon size={18} className={accent ? 'text-amber-500' : 'text-gold'} />
        </div>
      </div>
    </div>
  )
}

export default function AdminDashboard() {
  const [token, setToken] = useState<string | null>(null)
  
  useEffect(() => {
    fetch('/api/admin/session')
      .then(res => res.json())
      .then(s => {
        if (s?.token) setToken(s.token)
      })
      .catch(() => {})
  }, [])

  const stats = useQuery(
    api.analytics.getDashboardStats,
    token ? { token } : "skip"
  )
  const products = useQuery(api.products.listProducts, {})

  if (!stats || !products) {
    return (
      <div className="px-6 py-8 max-w-7xl mx-auto">
        <div className="h-8 w-48 bg-cream animate-pulse rounded mb-8" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-cream border border-gold/10 p-5 h-24 animate-pulse" />
          ))}
        </div>
      </div>
    )
  }

  const pieData = stats?.ordersByStatus 
    ? Object.entries(stats.ordersByStatus)
        .filter(([, v]) => (v as number) > 0)
        .map(([name, value]) => ({ name, value }))
    : []

  return (
    <div className="px-4 sm:px-6 py-8 max-w-7xl mx-auto">
      <h1 className="font-display text-brown text-2xl mb-8">Dashboard</h1>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          label="Total Revenue"
          value={formatPrice((stats?.totalRevenue || 0) / 100)}
          icon={TrendingUp}
        />
        <StatCard
          label="Total Orders"
          value={stats?.totalOrders || 0}
          icon={ShoppingBag}
        />
        <StatCard
          label="Pending Orders"
          value={(stats?.ordersByStatus as any)?.pending ?? 0}
          icon={Clock}
          accent
        />
        <StatCard
          label="Active Products"
          value={products.length}
          icon={Package}
        />
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6 mb-8">
        {/* Revenue line chart */}
        <div className="bg-cream border border-gold/10 p-6">
          <h2 className="font-display text-brown text-lg mb-4">
            Revenue — Last 6 Months
          </h2>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={stats.revenueByMonth}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(44,24,16,0.08)" />
              <XAxis
                dataKey="month"
                tick={{ fontFamily: 'Inter', fontSize: 11, fill: '#7a6a5a' }}
              />
              <YAxis
                tickFormatter={(v) => '₦' + (v / 100000).toFixed(0) + 'k'}
                tick={{ fontFamily: 'Inter', fontSize: 11, fill: '#7a6a5a' }}
                width={60}
              />
              <Tooltip
                formatter={(v: number) => [formatPrice(v / 100), 'Revenue']}
                contentStyle={{
                  fontFamily: 'Inter',
                  fontSize: 12,
                  border: '1px solid rgba(201,168,76,0.3)',
                  borderRadius: 0,
                }}
              />
              <Line
                type="monotone"
                dataKey="revenue"
                stroke="#C9A84C"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: '#C9A84C' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Orders pie chart */}
        <div className="bg-cream border border-gold/10 p-6">
          <h2 className="font-display text-brown text-lg mb-4">
            Orders by Status
          </h2>
          {pieData.length === 0 ? (
            <div className="h-60 flex items-center justify-center text-brown/30 font-body text-sm">
              No order data yet
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie
                  data={pieData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={90}
                  label={({ name, percent }) =>
                    `${name} ${(percent * 100).toFixed(0)}%`
                  }
                  labelLine={false}
                >
                  {pieData.map((_, index) => (
                    <Cell
                      key={index}
                      fill={PIE_COLORS[index % PIE_COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    fontFamily: 'Inter',
                    fontSize: 12,
                    border: '1px solid rgba(201,168,76,0.3)',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Top products */}
      <div className="bg-cream border border-gold/10 p-6">
        <h2 className="font-display text-brown text-lg mb-4">
          Top Products by Sales
        </h2>
        {stats.topProducts.length === 0 ? (
          <p className="font-body text-sm text-brown/40 py-8 text-center">
            No sales data yet
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full font-body text-sm">
              <thead>
                <tr className="border-b border-gold/10">
                  <th className="text-left py-3 pr-4 text-brown/50 font-normal text-xs tracking-widest uppercase">
                    Product
                  </th>
                  <th className="text-right py-3 pr-4 text-brown/50 font-normal text-xs tracking-widest uppercase">
                    Units Sold
                  </th>
                  <th className="text-right py-3 text-brown/50 font-normal text-xs tracking-widest uppercase">
                    Revenue
                  </th>
                </tr>
              </thead>
              <tbody>
                {stats.topProducts.map((p: any, i: number) => (
                  <tr
                    key={i}
                    className={i % 2 === 0 ? 'bg-cream' : 'bg-cream-warm'}
                  >
                    <td className="py-3 pr-4 text-brown">{p.name}</td>
                    <td className="py-3 pr-4 text-right text-brown/70">
                      {p.totalQuantity}
                    </td>
                    <td className="py-3 text-right text-gold">
                      {formatPrice(p.totalRevenue / 100)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}