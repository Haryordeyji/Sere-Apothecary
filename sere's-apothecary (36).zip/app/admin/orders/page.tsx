'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '@/convex/_generated/api'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronDown, ChevronUp } from 'lucide-react'

const STATUSES = ['pending','confirmed','processing','shipped','delivered','cancelled']

const statusColors: Record<string, string> = {
  pending:    'bg-amber-100 text-amber-700',
  confirmed:  'bg-blue-100 text-blue-700',
  processing: 'bg-purple-100 text-purple-700',
  shipped:    'bg-indigo-100 text-indigo-700',
  delivered:  'bg-green-100 text-green-700',
  cancelled:  'bg-red-100 text-red-600',
}

const formatPrice = (n?: number) =>
  `₦${(n || 0).toLocaleString('en-NG', { minimumFractionDigits: 2 })}`

const formatDate = (ts?: number) =>
  ts ? new Date(ts).toLocaleDateString('en-NG', {
    day: 'numeric', month: 'short', year: 'numeric'
  }) : 'N/A'

export default function AdminOrdersPage() {
  const [token, setToken] = useState<string | null>(null)
  
  useEffect(() => {
    fetch('/api/admin/session').then(res => res.json()).then(s => setToken(s?.token)).catch(()=>{})
  }, [])
  
  const orders = useQuery(
    api.orders.listOrders,
    token ? { token } : 'skip'
  )
  const updateStatus = useMutation(api.orders.updateFulfillmentStatus)

  const [statusFilter, setStatusFilter] = useState('all')
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null)
  const [pendingStatus, setPendingStatus] = useState<Record<string, string>>({})
  const [saving, setSaving] = useState<string | null>(null)

  const filtered = statusFilter === 'all'
    ? orders
    : orders?.filter((o) => o.fulfillmentStatus === statusFilter)

  const handleStatusUpdate = async (orderId: string) => {
    const newStatus = pendingStatus[orderId]
    if (!newStatus) return
    if (!token) return
    setSaving(orderId)
    try {
      await updateStatus({ 
        orderId: orderId as any,
        fulfillmentStatus: newStatus as any,
        token 
      })
    } finally {
      setSaving(null)
    }
  }

  return (
    <div className="px-4 sm:px-6 py-8 max-w-7xl mx-auto">
      <h1 className="font-display text-brown text-2xl mb-6">Orders</h1>

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap mb-6">
        {['all', ...STATUSES].map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`font-accent text-xs tracking-widest uppercase px-4 py-2 transition-colors ${
              statusFilter === s
                ? 'bg-gold text-brown'
                : 'border border-brown/20 text-brown/60 hover:border-gold hover:text-brown'
            }`}
          >
            {s === 'all' ? 'All' : s}
          </button>
        ))}
      </div>

      {!orders ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="h-16 bg-cream animate-pulse" />
          ))}
        </div>
      ) : filtered?.length === 0 ? (
        <div className="bg-cream border border-gold/10 p-12 text-center">
          <p className="font-display text-brown/40 text-xl">No orders found</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered?.map((order) => (
            <div key={order._id} className="bg-cream border border-gold/10">
              {/* Header row */}
              <button
                className="w-full flex items-center justify-between p-4 text-left hover:bg-cream-warm transition-colors"
                onClick={() =>
                  setExpandedOrder(
                    expandedOrder === order._id ? null : order._id
                  )
                }
              >
                <div className="flex items-center gap-4 min-w-0">
                  <span className="font-display text-gold text-sm shrink-0">
                    {order.trackingCode}
                  </span>
                  <span className="font-body text-brown text-sm truncate">
                    {order.customerName}
                  </span>
                  <span className="font-body text-brown/40 text-xs hidden sm:block">
                    {formatDate(order.createdAt)}
                  </span>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className={`font-accent text-[10px] tracking-widest uppercase px-2 py-1 rounded ${statusColors[order.fulfillmentStatus] || 'bg-gray-100 text-gray-600'}`}>
                    {order.fulfillmentStatus}
                  </span>
                  {expandedOrder === order._id
                    ? <ChevronUp size={16} className="text-brown/40" />
                    : <ChevronDown size={16} className="text-brown/40" />
                  }
                </div>
              </button>

              {/* Expanded */}
              <AnimatePresence>
                {expandedOrder === order._id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-4 border-t border-gold/10 pt-4">
                      <div className="grid sm:grid-cols-2 gap-6">
                        {/* Buyer details */}
                        <div>
                          <p className="font-accent text-[10px] tracking-widest uppercase text-gold/60 mb-3">
                            Buyer Details
                          </p>
                          <div className="space-y-1 font-body text-sm text-brown/70">
                            <p>{order.customerEmail}</p>
                            <p>{order.customerPhone}</p>
                            <p className="text-brown/50">{[order.deliveryAddress, order.deliveryCity, order.deliveryState].filter(Boolean).join(', ')}</p>
                          </div>
                        </div>

                        {/* Items */}
                        <div>
                          <p className="font-accent text-[10px] tracking-widest uppercase text-gold/60 mb-3">
                            Items
                          </p>
                          <div className="space-y-1">
                            {order.items.map((item: any, i: number) => (
                              <div key={i} className="flex justify-between font-body text-sm">
                                <span className="text-brown/70 truncate mr-2">
                                  {item.name} × {item.qty}
                                </span>
                                <span className="text-brown/60 shrink-0">
                                  {formatPrice((item.priceKobo * item.qty) / 100)}
                                </span>
                              </div>
                            ))}
                            <div className="flex justify-between font-display text-sm pt-2 border-t border-gold/10 mt-2">
                              <span className="text-brown">Subtotal</span>
                              <span className="text-gold">{formatPrice((order.subtotalKobo || 0) / 100)}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Status update */}
                      <div className="flex items-center gap-3 mt-4 pt-4 border-t border-gold/10">
                        <select
                          defaultValue={order.fulfillmentStatus}
                          onChange={(e) =>
                            setPendingStatus((prev) => ({
                              ...prev,
                              [order._id]: e.target.value,
                            }))
                          }
                          className="border border-brown/20 px-3 py-2 font-body text-sm text-brown focus:outline-none focus:border-gold bg-white"
                        >
                          {STATUSES.map((s) => (
                            <option key={s} value={s} className="capitalize">
                              {s.charAt(0).toUpperCase() + s.slice(1)}
                            </option>
                          ))}
                        </select>
                        <button
                          onClick={() => handleStatusUpdate(order._id)}
                          disabled={saving === order._id || !pendingStatus[order._id]}
                          className="btn-gold py-2 px-4 text-xs disabled:opacity-40"
                        >
                          {saving === order._id ? 'Saving...' : 'Update'}
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}