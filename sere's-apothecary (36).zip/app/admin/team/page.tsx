'use client'

import { useState, useEffect } from 'react'
import { useQuery, useMutation } from 'convex/react'
import { api } from '@/convex/_generated/api'
import { Plus, Trash2, Eye, EyeOff, Lock, ChevronDown } from 'lucide-react'

const formatDate = (ts?: number) =>
  ts ? new Date(ts).toLocaleDateString('en-NG', {
    day: 'numeric', month: 'short', year: 'numeric',
  }) : 'N/A'

export default function AdminTeamPage() {
  const [role, setRole] = useState<'master' | 'sub' | null>(null)
  const [token, setToken] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/admin/session').then(res => res.json()).then(s => {
      setRole(s?.role || null)
      setToken(s?.token || null)
    }).catch(()=>{})
  }, [])

  const adminsArgs = token ? { token } : "skip" as any
  const admins = useQuery(api.admins.listSubAdmins, adminsArgs)
  const createSubAdmin = useMutation(api.admins.provisionSubAdmin)
  const deleteAdmin = useMutation(api.admins.deactivateAdmin)

  const [showForm, setShowForm] = useState(false)
  const [newEmail, setNewEmail] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [showPwd, setShowPwd] = useState(false)
  const [addError, setAddError] = useState('')
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState<string | null>(null)

  if (role !== null && role !== 'master') {
    return (
      <div className="px-4 sm:px-6 py-8 max-w-lg mx-auto text-center">
        <div className="bg-cream border border-gold/10 p-12">
          <Lock size={32} className="text-brown/20 mx-auto mb-4" />
          <p className="font-display text-brown text-xl mb-2">Access Denied</p>
          <p className="font-body text-sm text-brown/50">
            Only the Master Admin can manage team members.
          </p>
        </div>
      </div>
    )
  }

  const handleCreate = async () => {
    if (!newEmail || !newPassword) {
      setAddError('Email and password are required.')
      return
    }
    if (newPassword.length < 8) {
      setAddError('Password must be at least 8 characters.')
      return
    }
    setSaving(true)
    setAddError('')
    try {
      if (!token) throw new Error("No token")
      await createSubAdmin({ token, email: newEmail, password: newPassword })
      setNewEmail('')
      setNewPassword('')
      setShowForm(false)
    } catch (e: any) {
      setAddError(e.message || 'Failed to create admin.')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string, email: string) => {
    if (!confirm(`Remove admin access for ${email}?`)) return
    setDeleting(id)
    try { 
      if (!token) throw new Error("No token")
      await deleteAdmin({ token, targetAdminId: id as any }) 
    }
    catch (e: any) { alert(e.message) }
    finally { setDeleting(null) }
  }

  return (
    <div className="px-4 sm:px-6 py-8 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-2">
        <h1 className="font-display text-brown text-2xl">Team Management</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="btn-gold flex items-center gap-2 py-2 px-4"
        >
          <Plus size={16} />
          Add Sub-Admin
          <ChevronDown size={14} className={showForm ? 'rotate-180' : ''} />
        </button>
      </div>
      <p className="font-body text-sm text-brown/40 mb-6">
        Manage admin access to the portal.
      </p>

      {/* Add form */}
      {showForm && (
        <div className="bg-cream border border-gold/20 p-6 mb-6">
          <p className="font-accent text-xs tracking-widest uppercase text-gold/60 mb-4">
            New Sub-Admin
          </p>
          <div className="grid sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="font-body text-xs text-brown/60 uppercase tracking-widest mb-1 block">
                Email
              </label>
              <input
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="w-full border border-brown/20 px-4 py-2.5 font-body text-brown text-sm focus:outline-none focus:border-gold bg-white"
                placeholder="subadmin@email.com"
              />
            </div>
            <div>
              <label className="font-body text-xs text-brown/60 uppercase tracking-widest mb-1 block">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPwd ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full border border-brown/20 px-4 py-2.5 pr-10 font-body text-brown text-sm focus:outline-none focus:border-gold bg-white"
                  placeholder="Min 8 characters"
                />
                <button
                  type="button"
                  onClick={() => setShowPwd(!showPwd)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-brown/30"
                >
                  {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>
          </div>
          {addError && (
            <p className="text-red-500 text-xs mb-3">{addError}</p>
          )}
          <div className="flex gap-3">
            <button
              onClick={handleCreate}
              disabled={saving}
              className="btn-gold py-2 px-6 disabled:opacity-50"
            >
              {saving ? 'Creating...' : 'Create Sub-Admin'}
            </button>
            <button
              onClick={() => { setShowForm(false); setAddError('') }}
              className="btn-outline-gold py-2 px-6"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Admins table */}
      {!admins ? (
        <div className="space-y-2">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="h-14 bg-cream animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="bg-cream border border-gold/10 overflow-hidden">
          <table className="w-full font-body text-sm">
            <thead>
              <tr className="border-b border-gold/10 bg-cream-warm">
                {['Email', 'Role', 'Added', 'Actions'].map((h) => (
                  <th key={h} className="text-left px-4 py-3 text-brown/50 font-normal text-xs tracking-widest uppercase">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {admins.map((admin) => (
                <tr key={admin._id} className="border-b border-gold/5 hover:bg-cream-warm transition-colors">
                  <td className="px-4 py-3 text-brown">{admin.email}</td>
                  <td className="px-4 py-3">
                    <span className="font-accent text-[10px] tracking-widest uppercase px-2 py-1 bg-cream border border-brown/20 text-brown/60">
                      sub
                    </span>
                  </td>
                  <td className="px-4 py-3 text-brown/40 text-xs">
                    {formatDate(admin.createdAt)}
                  </td>
                  <td className="px-4 py-3">
                      <button
                        onClick={() => handleDelete(admin._id, admin.email)}
                        disabled={deleting === admin._id}
                        className="text-brown/30 hover:text-red-500 transition-colors disabled:opacity-40"
                      >
                        <Trash2 size={16} />
                      </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}