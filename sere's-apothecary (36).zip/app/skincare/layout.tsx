import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Skincare',
  description: 'Discover premium skincare rituals to nourish and rejuvenate your skin, curated by Sere\'s Apothecary.',
  openGraph: {
    title: 'Skincare | Sere\'s Apothecary',
    description: 'Discover premium skincare rituals to nourish and rejuvenate your skin, curated by Sere\'s Apothecary.',
  }
}

export default function SkincareLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
