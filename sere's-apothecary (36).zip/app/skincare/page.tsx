'use client'

import ShopLayout from '@/components/ShopLayout'
import { useQuery } from 'convex/react'
import { api } from '@/convex/_generated/api'
import { Search, SlidersHorizontal } from 'lucide-react'
import { useState, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import ProductGridSkeleton from '@/components/ProductGridSkeleton'
import ProductCard from '@/components/ProductCard'

export default function SkincarePage() {
  const products = useQuery(api.products.listProducts, { category: 'skincare' })
  const router = useRouter()

  const [searchQuery, setSearchQuery] = useState('')
  const [priceSort, setPriceSort] = useState('default')

  const filteredProducts = useMemo(() => {
    if (!products) return undefined
    let filtered = [...products]

    if (searchQuery) {
      filtered = filtered.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }
    if (priceSort === 'low') {
      filtered.sort((a, b) => (a.priceKobo || 0) - (b.priceKobo || 0))
    } else if (priceSort === 'high') {
      filtered.sort((a, b) => (b.priceKobo || 0) - (a.priceKobo || 0))
    }

    return filtered
  }, [products, searchQuery, priceSort])

  return (
    <ShopLayout>
      <div className="bg-cream-warm min-h-screen pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="font-display text-4xl md:text-5xl text-brown font-light mb-4">Premium Skincare</h1>
            <p className="font-body text-brown/60 text-sm tracking-wide">NOURISH AND REJUVENATE YOUR SKIN</p>
          </div>

          <div className="flex flex-col md:flex-row gap-4 justify-between items-center mb-8 bg-cream p-4 rounded-sm border border-brown/5">
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-brown/40" size={18} />
              <input 
                type="text" 
                placeholder="Search skincare products..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-brown/10 bg-white font-body text-sm focus:outline-none focus:border-gold transition-colors block text-brown placeholder-brown/40"
              />
            </div>
            
            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="flex items-center gap-2 w-full md:w-auto">
                <SlidersHorizontal size={18} className="text-brown/40 hidden md:block" />
                <select
                  value="skincare"
                  onChange={(e) => {
                    const val = e.target.value
                    if (val === 'all') router.push('/collection')
                    else if (val === 'perfume') router.push('/perfumes')
                  }}
                  className="border border-brown/10 bg-white font-body text-sm py-2 px-3 focus:outline-none focus:border-gold text-brown flex-1 md:flex-none"
                >
                  <option value="all">All Categories</option>
                  <option value="perfume">Perfumes</option>
                  <option value="skincare">Skincare</option>
                </select>
                <select
                  value={priceSort}
                  onChange={(e) => setPriceSort(e.target.value)}
                  className="border border-brown/10 bg-white font-body text-sm py-2 px-3 focus:outline-none focus:border-gold text-brown flex-1 md:flex-none"
                >
                  <option value="default">Sort by</option>
                  <option value="low">Price: Low to High</option>
                  <option value="high">Price: High to Low</option>
                </select>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts === undefined ? (
              <ProductGridSkeleton count={8} />
            ) : filteredProducts.length === 0 ? (
              <div className="col-span-full text-center py-12 text-brown/50 font-body border border-brown/10 bg-cream">
                No skincare products found matching your criteria.
              </div>
            ) : (
              filteredProducts.map((product) => (
                <ProductCard key={product._id} product={product} />
              ))
            )}
          </div>
        </div>
      </div>
    </ShopLayout>
  )
}
