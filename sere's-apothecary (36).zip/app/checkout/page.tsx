'use client'

import ShopLayout from '@/components/ShopLayout'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useCart } from '@/context/CartContext'
import Link from 'next/link'
import { ShoppingBag } from 'lucide-react'

declare global {
  interface Window {
    PaystackPop: {
      setup: (config: any) => { openIframe: () => void }
    }
  }
}

export default function CheckoutPage() {
  const router = useRouter()
  const { items, total, subtotal, discountAmount, discountPercent, clearCart } = useCart()

  const [buyerName, setBuyerName] = useState('')
  const [buyerEmail, setBuyerEmail] = useState('')
  const [buyerPhone, setBuyerPhone] = useState('')
  const [buyerAddress, setBuyerAddress] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  useEffect(() => {
    const script = document.createElement('script')
    script.src = 'https://js.paystack.co/v1/inline.js'
    script.async = true
    document.body.appendChild(script)

    return () => {
      document.body.removeChild(script)
    }
  }, [])

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    let isValid = true

    if (!buyerName || buyerName.length < 2) {
      newErrors.buyerName = 'Please enter a valid full name'
      isValid = false
    }

    if (!buyerEmail || !buyerEmail.includes('@') || !buyerEmail.includes('.')) {
      newErrors.buyerEmail = 'Please enter a valid email address'
      isValid = false
    }

    if (!buyerPhone || buyerPhone.length < 10) {
      newErrors.buyerPhone = 'Please enter a valid phone number'
      isValid = false
    }

    if (!buyerAddress || buyerAddress.length < 10) {
      newErrors.buyerAddress = 'Please enter a detailed delivery address'
      isValid = false
    }

    setErrors(newErrors)
    return isValid
  }

  const handlePayment = () => {
    if (!validateForm()) return
    setIsLoading(true)
    
    // Check if Paystack is loaded
    if (!window.PaystackPop) {
      setErrors({ form: 'Payment gateway is loading. Please try again in a moment.' })
      setIsLoading(false)
      return
    }

    const handler = window.PaystackPop.setup({
      key: process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY || '',
      email: buyerEmail,
      amount: Math.round(total * 100),
      currency: 'NGN',
      ref: 'SA_' + Date.now(),
      metadata: {
        custom_fields: [],
        buyerName,
        buyerPhone,
        buyerAddress,
        deliveryCity: "",
        deliveryState: "",
        items: items.map(i => ({
          productId: i.id,
          name: i.name,
          priceKobo: i.price * 100,
          qty: i.quantity,
          imageUrl: i.imageUrl ?? ""
        }))
      },
      callback: (response: { reference: string }) => {
        clearCart()
        router.push('/order-confirmed?ref=' + response.reference)
      },
      onClose: () => {
        setIsLoading(false)
      }
    })
    handler.openIframe()
  }

  const formatPrice = (amount: number) => {
    return `₦${amount.toLocaleString('en-NG', { minimumFractionDigits: 2 })}`
  }

  if (items.length === 0) {
    return (
      <ShopLayout>
        <div className="min-h-[60vh] flex flex-col items-center justify-center px-4 bg-cream-warm">
          <ShoppingBag size={48} className="text-brown/20 mb-4" />
          <h2 className="font-display text-2xl text-brown mb-2">Your cart is empty</h2>
          <p className="font-body text-brown/60 mb-6">Looks like you haven&apos;t added anything yet.</p>
          <Link href="/" className="btn-gold px-8 py-3">
            Continue Shopping
          </Link>
        </div>
      </ShopLayout>
    )
  }

  return (
    <ShopLayout>
      <div className="bg-cream-warm min-h-screen">
        <div className="max-w-6xl mx-auto px-4 py-12">
          {/* PAGE HEADING */}
          <h1 className="font-display text-brown text-3xl mb-8">Checkout</h1>

          {/* TWO COLUMN GRID */}
          <div className="grid lg:grid-cols-5 gap-12">
            
            {/* LEFT COL */}
            <div className="lg:col-span-3">
              <h2 className="font-display text-xl text-brown mb-6">Your Details</h2>

              <div className="mb-4">
                <label className="font-body text-sm text-brown/70 mb-1 block">Full Name</label>
                <input
                  type="text"
                  value={buyerName}
                  onChange={(e) => setBuyerName(e.target.value)}
                  className={`w-full border px-4 py-3 font-body text-brown focus:outline-none transition-colors ${
                    errors.buyerName ? 'border-red-400 focus:border-red-500' : 'border-brown/20 focus:border-gold'
                  } bg-white`}
                  placeholder="John Doe"
                />
                {errors.buyerName && <p className="text-xs text-red-500 mt-1">{errors.buyerName}</p>}
              </div>

              <div className="mb-4">
                <label className="font-body text-sm text-brown/70 mb-1 block">Email Address</label>
                <input
                  type="email"
                  value={buyerEmail}
                  onChange={(e) => setBuyerEmail(e.target.value)}
                  className={`w-full border px-4 py-3 font-body text-brown focus:outline-none transition-colors ${
                    errors.buyerEmail ? 'border-red-400 focus:border-red-500' : 'border-brown/20 focus:border-gold'
                  } bg-white`}
                  placeholder="john@example.com"
                />
                {errors.buyerEmail && <p className="text-xs text-red-500 mt-1">{errors.buyerEmail}</p>}
              </div>

              <div className="mb-4">
                <label className="font-body text-sm text-brown/70 mb-1 block">Phone Number</label>
                <input
                  type="tel"
                  value={buyerPhone}
                  onChange={(e) => setBuyerPhone(e.target.value)}
                  className={`w-full border px-4 py-3 font-body text-brown focus:outline-none transition-colors ${
                    errors.buyerPhone ? 'border-red-400 focus:border-red-500' : 'border-brown/20 focus:border-gold'
                  } bg-white`}
                  placeholder="08012345678"
                />
                {errors.buyerPhone && <p className="text-xs text-red-500 mt-1">{errors.buyerPhone}</p>}
              </div>

              <div className="mb-4">
                <label className="font-body text-sm text-brown/70 mb-1 block">Delivery Address</label>
                <textarea
                  rows={3}
                  value={buyerAddress}
                  onChange={(e) => setBuyerAddress(e.target.value)}
                  className={`w-full border px-4 py-3 font-body text-brown focus:outline-none transition-colors ${
                    errors.buyerAddress ? 'border-red-400 focus:border-red-500' : 'border-brown/20 focus:border-gold'
                  } bg-white`}
                  placeholder="123 Luxury Avenue, GRA, Benin City"
                />
                {errors.buyerAddress && <p className="text-xs text-red-500 mt-1">{errors.buyerAddress}</p>}
              </div>

              {errors.form && (
                <div className="mt-4 p-3 bg-red-50 border border-red-200 text-red-600 text-sm">
                  {errors.form}
                </div>
              )}

              <div className="border-l-4 border-gold bg-amber-50 p-4 mt-6 mb-6">
                <p className="font-body text-sm text-amber-800 leading-relaxed">
                  <strong>IMPORTANT:</strong> The amount charged is strictly the product price. Delivery fee is NOT included and will be communicated after order confirmation.
                </p>
              </div>

              <button
                disabled={isLoading}
                onClick={handlePayment}
                className="btn-gold w-full py-4 text-base mt-2 flex justify-center items-center"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin border-2 border-brown/30 border-t-brown rounded-full w-5 h-5 mr-3" />
                    Processing...
                  </>
                ) : (
                  `Pay ${formatPrice(total)} with Paystack`
                )}
              </button>
            </div>

            {/* RIGHT COL */}
            <div className="lg:col-span-2">
              <div className="sticky top-6">
                <h2 className="font-display text-xl text-brown mb-4">Order Summary</h2>
                <div className="border border-gold/20 bg-cream p-6 rounded-sm">
                  
                  <div className="space-y-3 mb-4">
                    {items.map((item, index) => (
                      <div key={`${item.id}-${index}`} className="flex justify-between items-start">
                        <div className="pr-4">
                          <p className="font-body text-sm text-brown/70 leading-tight">
                            <span className="line-clamp-1">{item.name}</span>
                            <span className="text-xs mt-1 block tracking-wider">x{item.quantity}</span>
                          </p>
                        </div>
                        <p className="font-body text-sm text-brown whitespace-nowrap">
                          {formatPrice(item.price * item.quantity)}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-gold/10 my-4" />

                  {discountAmount > 0 && (
                    <>
                      <div className="flex justify-between text-brown/60 text-sm mb-2">
                        <span>Subtotal</span>
                        <span>{formatPrice(subtotal)}</span>
                      </div>
                      <div className="flex justify-between text-green-600 text-sm mb-2">
                        <span>Discount ({discountPercent}%)</span>
                        <span>-{formatPrice(discountAmount)}</span>
                      </div>
                    </>
                  )}

                  <div className="flex justify-between mt-2 pt-2 border-t border-gold/10">
                    <span className="font-display text-brown text-lg">Total</span>
                    <span className="font-display text-gold text-lg">{formatPrice(total)}</span>
                  </div>

                  <p className="mt-4 text-xs text-brown/40 italic text-right">
                    Delivery fee not included
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </ShopLayout>
  )
}
