import type { Metadata } from 'next'
import { Cormorant_Garamond, Inter, Cinzel } from 'next/font/google'
import { ConvexClientProvider } from '@/components/ConvexClientProvider'
import { CartProvider } from '@/context/CartContext'
import { WishlistProvider } from '@/context/WishlistContext'
import { Toaster } from 'react-hot-toast'
import './globals.css'

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['300', '400', '600'],
  variable: '--font-display',
  display: 'swap',
})

const inter = Inter({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-body',
  display: 'swap',
})

const cinzel = Cinzel({
  subsets: ['latin'],
  weight: ['400', '600'],
  variable: '--font-accent',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL || 'https://seresapothecary.com'
  ),
  title: {
    template: "%s | Sere's Apothecary",
    default: "Sere's Apothecary of Skincare and Perfume",
  },
  description:
    'Luxury curator of premium perfumes and skincare. Discover globally sourced fragrances and beauty rituals, delivered from Benin City, Nigeria.',
  keywords: ['luxury perfume Nigeria', 'premium skincare Benin City'],
  openGraph: {
    type: 'website',
    siteName: "Sere's Apothecary",
    locale: 'en_NG',
  },
  robots: { index: true, follow: true },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html
      lang="en"
      className={`${cormorant.variable} ${inter.variable} ${cinzel.variable}`}
    >
      <body className="font-body bg-cream-warm text-brown antialiased">
        <ConvexClientProvider>
          <CartProvider>
            <WishlistProvider>
              {children}
              <Toaster 
                position="bottom-right"
                toastOptions={{
                  duration: 3000,
                  style: {
                    background: '#2C1810',
                    color: '#F5F0E8',
                    border: '1px solid #C9A84C',
                    fontFamily: 'var(--font-body)',
                  },
                }}
              />
            </WishlistProvider>
          </CartProvider>
        </ConvexClientProvider>
      </body>
    </html>
  )
}