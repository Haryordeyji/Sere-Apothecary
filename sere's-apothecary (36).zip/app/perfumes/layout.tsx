import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Perfumes',
  description: 'Explore our luxury collection of exquisite perfumes, sourced from the finest ingredients worldwide.',
  openGraph: {
    title: 'Perfumes | Sere\'s Apothecary',
    description: 'Explore our luxury collection of exquisite perfumes, sourced from the finest ingredients worldwide.',
  }
}

export default function PerfumesLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
