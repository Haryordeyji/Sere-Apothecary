'use client'

import ShopLayout from '@/components/ShopLayout'
import Link from 'next/link'
import { motion } from 'framer-motion'

export default function NotFound() {
  return (
    <ShopLayout>
      <div className="bg-cream-warm min-h-screen pt-32 pb-20 flex flex-col items-center justify-center px-4 text-center">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="font-display text-8xl text-brown/20 font-light mb-4 text-brown">
            404
          </h1>
          <h2 className="font-display text-3xl text-brown mb-6">
            Page Not Found
          </h2>
          <p className="font-body text-brown/60 text-lg mb-8 max-w-md mx-auto">
            The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
          </p>
          <Link href="/" className="btn-gold px-8 py-3">
            Return to Home
          </Link>
        </motion.div>
      </div>
    </ShopLayout>
  )
}
