'use client'

import { useEffect } from 'react'
import ShopLayout from '@/components/ShopLayout'
import Link from 'next/link'

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    console.error('Unhandled app error:', error)
  }, [error])

  return (
    <ShopLayout>
      <div className="bg-cream-warm min-h-screen pt-32 pb-20 flex flex-col items-center justify-center px-4 text-center">
        <h1 className="font-display text-4xl text-brown mb-6">
          Something went wrong
        </h1>
        <p className="font-body text-brown/60 mb-8 max-w-md mx-auto">
          We apologize for the inconvenience. An unexpected error has occurred.
        </p>
        <div className="flex gap-4 justify-center">
          <button onClick={() => reset()} className="btn-gold px-6 py-3">
            Try Again
          </button>
          <Link href="/" className="btn-outline-gold px-6 py-3">
            Go Home
          </Link>
        </div>
      </div>
    </ShopLayout>
  )
}
