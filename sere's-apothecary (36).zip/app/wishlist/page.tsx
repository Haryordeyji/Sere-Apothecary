'use client'

import ShopLayout from '@/components/ShopLayout'
import { useWishlist } from '@/context/WishlistContext'
import { Heart } from 'lucide-react'
import Link from 'next/link'
import ProductCard from '@/components/ProductCard'

export default function WishlistPage() {
  const { items } = useWishlist()

  return (
    <ShopLayout>
      <div className="bg-cream-warm min-h-screen pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="font-display text-4xl md:text-5xl text-brown font-light mb-4">Your Wishlist</h1>
            <p className="font-body text-brown/60 text-sm tracking-wide">SAVED ITEMS FOR LATER</p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {items.length === 0 ? (
              <div className="col-span-full text-center py-20 border border-brown/10 bg-cream flex flex-col items-center">
                <Heart size={48} className="text-brown/20 mb-4" />
                <h2 className="font-display text-2xl text-brown mb-2">Your wishlist is empty</h2>
                <p className="font-body text-brown/60 mb-6">Explore our collection and add your favorite items here.</p>
                <Link href="/collection" className="btn-gold px-8 py-3">
                  Browse Collection
                </Link>
              </div>
            ) : (
              items.map((product) => (
                <ProductCard 
                  key={product.id} 
                  product={{
                    _id: product.id,
                    name: product.name,
                    price: product.price,
                    imageUrl: product.imageUrl,
                    category: product.category
                  }} 
                />
              ))
            )}
          </div>
        </div>
      </div>
    </ShopLayout>
  )
}
