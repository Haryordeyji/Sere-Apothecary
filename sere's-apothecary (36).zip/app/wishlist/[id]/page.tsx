'use client'

import ShopLayout from '@/components/ShopLayout'
import { useParams } from 'next/navigation'
import { useQuery } from 'convex/react'
import { api } from '@/convex/_generated/api'
import Image from 'next/image'
import { Id } from '@/convex/_generated/dataModel'
import { Heart } from 'lucide-react'
import { useCart } from '@/context/CartContext'
import { useWishlist } from '@/context/WishlistContext'
import { useState } from 'react'

export default function ProductDetailPage() {
  const params = useParams()
  const productId = params.id as Id<"products">
  const product = useQuery(api.products.getProduct, { id: productId })

  const { addToCart } = useCart()
  const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist()
  const [quantity, setQuantity] = useState(1)

  const handleWishlistToggle = () => {
    if (!product) return
    if (isInWishlist(product._id)) {
      removeFromWishlist(product._id)
    } else {
      addToWishlist({
        id: product._id,
        name: product.name,
        price: (product.priceKobo || 0) / 100,
        imageUrl: product.images?.[0] || '/placeholder-product.jpg',
        category: product.category
      })
    }
  }

  const formatPrice = (amount: number) => {
    return `₦${amount.toLocaleString('en-NG', { minimumFractionDigits: 2 })}`
  }

  if (product === undefined) {
    return (
      <ShopLayout>
        <div className="bg-cream-warm min-h-screen pt-32 pb-20 flex items-center justify-center">
          <p className="font-body text-brown/60 text-lg animate-pulse">Loading product...</p>
        </div>
      </ShopLayout>
    )
  }

  if (product === null) {
    return (
      <ShopLayout>
        <div className="bg-cream-warm min-h-screen pt-32 pb-20 text-center">
          <h1 className="font-display text-4xl text-brown mb-4">Product Not Found</h1>
          <p className="font-body text-brown/60">We couldn&apos;t find the product you&apos;re looking for.</p>
        </div>
      </ShopLayout>
    )
  }

  return (
    <ShopLayout>
      <div className="bg-cream-warm min-h-screen pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-4">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-24">
            <div className="relative aspect-square md:aspect-[3/4] w-full bg-cream rounded-sm overflow-hidden border border-gold/10">
              <Image
                src={product.images?.[0] || '/placeholder-product.jpg'}
                alt={product.name}
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
                priority
              />
              <div className="absolute top-4 left-4 bg-cream/90 backdrop-blur-sm px-3 py-1">
                <span className="font-accent text-xs tracking-wider text-brown uppercase">
                  {product.category}
                </span>
              </div>
            </div>

            <div className="flex flex-col justify-center">
              <h1 className="font-display text-4xl md:text-5xl text-brown mb-4 leading-tight">
                {product.name}
              </h1>
              
              <p className="font-body text-gold text-2xl mb-8">
                {formatPrice((product.priceKobo || 0) / 100)}
              </p>

              <div className="bg-cream p-6 border border-gold/10 mb-8 rounded-sm">
                <p className="font-body text-brown/80 leading-relaxed">
                  {product.description || "Indulge in a luxurious experience crafted to perfection. This product uses the finest ingredients to elevate your daily routine."}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="flex items-center bg-cream border border-gold/20 mr-0 sm:mr-4">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-4 py-3 text-brown hover:text-gold transition-colors"
                  >
                    -
                  </button>
                  <span className="font-body text-brown min-w-[2rem] text-center">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(Math.min(10, quantity + 1))}
                    className="px-4 py-3 text-brown hover:text-gold transition-colors"
                  >
                    +
                  </button>
                </div>

                <button
                  onClick={() => addToCart({
                    id: product._id,
                    name: product.name,
                    price: (product.priceKobo || 0) / 100,
                    imageUrl: product.images?.[0] || '/placeholder-product.jpg',
                    category: product.category,
                    quantity: quantity
                  })}
                  className="flex-1 btn-gold py-4 text-sm"
                >
                  Add to Cart
                </button>

                <button
                  onClick={handleWishlistToggle}
                  className="bg-cream border border-gold/20 p-4 text-brown/50 hover:text-brown hover:border-gold transition-all"
                  aria-label="Add to wishlist"
                >
                  <Heart size={20} className={isInWishlist(product._id) ? "fill-brown text-brown" : ""} />
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </ShopLayout>
  )
}

