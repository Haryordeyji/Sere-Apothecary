'use client'

import ShopLayout from '@/components/ShopLayout'
import { useState } from 'react'
import { useQuery } from 'convex/react'
import { api } from '@/convex/_generated/api'
import { motion } from 'framer-motion'
import { SearchX, CheckCircle2, Circle } from 'lucide-react'
import Link from 'next/link'

export default function TrackPage() {
  const [trackingInput, setTrackingInput] = useState('')
  const [submittedCode, setSubmittedCode] = useState('')
  const [hasSearched, setHasSearched] = useState(false)

  const orderResult = useQuery(
    api.orders.getOrderByTracking,
    submittedCode ? { trackingCode: submittedCode } : 'skip'
  )

  const handleTrack = () => {
    if (trackingInput.trim()) {
      setSubmittedCode(trackingInput.trim())
      setHasSearched(true)
    }
  }

  const formatPrice = (amount: number) => {
    return `₦${amount.toLocaleString('en-NG', { minimumFractionDigits: 2 })}`
  }

  const statuses = ['processing', 'shipped', 'delivered']

  return (
    <ShopLayout>
      <div className="bg-cream-warm min-h-screen pb-20">
        {/* PAGE HEADER */}
        <section className="bg-brown py-20 text-center">
          <p className="font-accent text-gold/60 tracking-[0.3em] text-xs uppercase mb-3">
            Order Status
          </p>
          <h1 className="font-display text-cream text-4xl md:text-5xl font-light">
            Track Your Order
          </h1>
        </section>

        {/* SEARCH SECTION */}
        <section className="max-w-lg mx-auto mt-12 px-4">
          <p className="font-body text-brown/60 text-sm mb-2">
            Enter your tracking code
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={trackingInput}
              onChange={(e) => setTrackingInput(e.target.value.toUpperCase())}
              placeholder="SA-XXXX-2026"
              className="flex-1 border border-brown/20 px-4 py-3 font-body text-brown uppercase tracking-widest focus:outline-none focus:border-gold transition-colors bg-white w-full"
            />
            <button 
              onClick={handleTrack}
              className="btn-gold px-6 py-3 w-full sm:w-auto"
            >
              Track
            </button>
          </div>
        </section>

        {/* RESULTS */}
        {hasSearched && (
          <div className="max-w-2xl mx-auto mt-12 px-4">
            {orderResult === undefined ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin border-2 border-gold border-t-transparent rounded-full w-8 h-8 mx-auto" />
              </div>
            ) : orderResult === null ? (
              <div className="text-center py-12">
                <SearchX size={48} className="text-brown/20 mx-auto" />
                <h2 className="font-display text-2xl text-brown/50 mt-4">
                  No order found
                </h2>
                <p className="font-body text-brown/40 mt-2">
                  Double-check your tracking code...
                </p>
                <div className="mt-4">
                  <a
                    href="https://wa.link/q4durx"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-body text-gold hover:text-gold-light transition-colors text-sm"
                  >
                    Contact support on WhatsApp
                  </a>
                </div>
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                {/* TRACKING CODE display */}
                <div className="text-center mb-8">
                  <p className="font-accent text-gold/60 text-xs tracking-widest uppercase">
                    Tracking Code
                  </p>
                  <p className="font-display text-3xl text-brown tracking-widest mt-1">
                    {orderResult.trackingCode}
                  </p>
                </div>

                {/* STATUS TIMELINE */}
                {orderResult.fulfillmentStatus === 'cancelled' ? (
                  <div className="bg-red-50 border border-red-200 text-red-600 text-center py-4 rounded-sm">
                    <p className="font-display text-lg">Order Cancelled</p>
                  </div>
                ) : (
                  <div className="flex items-center justify-between mt-8 mb-12 sm:px-8">
                    {statuses.map((status, index) => {
                      const currentIndex = statuses.indexOf(orderResult.fulfillmentStatus)
                      const isReached = index <= currentIndex
                      const isPast = index < currentIndex

                      return (
                        <div key={status} className="flex items-center flex-1 last:flex-none">
                          <div className="flex flex-col items-center relative">
                            {isReached ? (
                              <CheckCircle2 size={24} className="text-gold bg-cream-warm rounded-full z-10" />
                            ) : (
                              <Circle size={24} className="text-brown/20 bg-cream-warm rounded-full z-10" />
                            )}
                            <span
                              className={`absolute top-8 text-[10px] sm:text-xs font-body capitalize whitespace-nowrap ${
                                isReached ? 'text-brown font-medium' : 'text-brown/30'
                              }`}
                            >
                              {status}
                            </span>
                          </div>
                          {index < statuses.length - 1 && (
                            <div
                              className={`flex-1 h-px w-full mx-2 ${
                                isPast ? 'bg-gold/60' : 'bg-gold/20'
                              }`}
                            />
                          )}
                        </div>
                      )
                    })}
                  </div>
                )}

                {/* ORDER DETAILS */}
                <div className="bg-cream border border-gold/10 p-6 mt-16 rounded-sm">
                  <h3 className="font-accent text-gold/60 text-xs tracking-widest uppercase mb-4">
                    Items Ordered
                  </h3>
                  <div className="space-y-4">
                    {orderResult.items.map((item: any, index: number) => (
                      <div
                        key={index}
                        className="flex justify-between items-start font-body text-brown text-sm pb-4 border-b border-gold/10 last:border-0 last:pb-0"
                      >
                        <div className="flex-1 pr-4">
                          <p>{item.name || 'Unknown Product'}</p>
                          <p className="text-brown/60 text-xs mt-1">
                            Qty: {item.qty} × {formatPrice((item.priceKobo || 0) / 100)}
                          </p>
                        </div>
                        <p className="font-medium">
                          {formatPrice(((item.priceKobo || 0) * item.qty) / 100)}
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-4 pt-4 border-t border-brown/10">
                    <div className="flex justify-between items-center text-brown mb-2">
                       <span className="font-display">Subtotal:</span>
                       <span className="font-display">{formatPrice((orderResult.subtotalKobo || 0) / 100)}</span>
                    </div>
                  </div>

                  <div className="mt-6 bg-amber-50/50 border-l-2 border-gold/40 px-3 py-2">
                    <p className="font-body text-xs text-amber-800">
                      <strong>Note:</strong> Delivery fee is communicated separately and is not included in this total.
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        )}
      </div>
    </ShopLayout>
  )
}
