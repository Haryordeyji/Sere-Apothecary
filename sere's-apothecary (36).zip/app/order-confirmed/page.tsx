'use client'

import ShopLayout from '@/components/ShopLayout'
import { useSearchParams, useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Check, MessageCircle, AlertCircle } from 'lucide-react'
import Link from 'next/link'
import { Suspense, useEffect, useState } from 'react'
import { useAction } from 'convex/react'
import { api } from '@/convex/_generated/api'

function OrderConfirmedContent() {
  const searchParams = useSearchParams()
  const trackingCodeFromUrl = searchParams.get('tracking') ?? ''
  const paystackRef = searchParams.get('ref') ?? ''
  
  const [trackingCode, setTrackingCode] = useState(trackingCodeFromUrl)
  const [isVerifying, setIsVerifying] = useState(!!paystackRef && !trackingCodeFromUrl)
  const [error, setError] = useState('')

  // @ts-ignore
  const verifyPayment = useAction(api.payments.verifyAndProcessPayment)

  useEffect(() => {
    if (paystackRef && !trackingCodeFromUrl) {
      verifyPayment({ reference: paystackRef })
        .then((res) => {
          setTrackingCode(res.trackingCode)
          setIsVerifying(false)
        })
        .catch((err) => {
          console.error('Payment verification failed:', err)
          setError('Failed to verify your payment. Please contact support if you were charged.')
          setIsVerifying(false)
        })
    }
  }, [paystackRef, trackingCodeFromUrl, verifyPayment])

  return (
    <div className="min-h-screen flex items-center justify-center py-20 px-4 bg-cream-warm">
      <div className="max-w-lg w-full text-center">
        {isVerifying ? (
          <div className="flex flex-col items-center justify-center py-12">
            <div className="animate-spin border-4 border-gold border-t-transparent rounded-full w-16 h-16 mb-6" />
            <h2 className="font-display text-2xl text-brown mb-2">Verifying Payment...</h2>
            <p className="font-body text-brown/60">Please wait while we confirm your order.</p>
          </div>
        ) : error ? (
           <div className="flex flex-col items-center justify-center py-12">
            <AlertCircle size={48} className="text-red-500 mb-4" />
            <h2 className="font-display text-2xl text-brown mb-2">Verification Error</h2>
            <p className="font-body text-red-600 mb-6">{error}</p>
            <Link href="/" className="btn-outline-gold px-6 py-2">
              Return Home
            </Link>
          </div>
        ) : (
          <>
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 200, delay: 0.1 }}
              className="w-20 h-20 rounded-full border-2 border-gold flex items-center justify-center mx-auto"
            >
              <Check size={32} className="text-gold" />
            </motion.div>

            <h1 className="font-display text-brown text-3xl mt-6 mb-3">
              Order Confirmed!
            </h1>

            <p className="font-body text-brown/60 leading-relaxed">
              Thank you for your order. A confirmation email has been sent to your inbox with your tracking details.
            </p>

            {trackingCode && (
              <div className="bg-cream border border-gold/20 rounded-sm p-6 mt-6 mb-6 inline-block w-full">
                <p className="font-accent text-gold/60 text-xs tracking-widest uppercase mb-2">
                  Your Tracking Code
                </p>
                <p className="font-display text-2xl text-brown tracking-widest">
                  {trackingCode}
                </p>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-3 justify-center mt-6">
              <Link href="/track" className="btn-gold px-6 py-2">
                Track Your Order
              </Link>
              <Link href="/" className="btn-outline-gold px-6 py-2">
                Continue Shopping
              </Link>
            </div>

            <div className="mt-8 text-xs text-amber-700 bg-amber-50 border-l-2 border-amber-300 p-3 text-left">
              Delivery fee is NOT included in the amount charged and will be communicated separately.
            </div>

            <p className="mt-6 font-body text-sm text-brown/50">
              Questions?{' '}
              <a
                href="https://wa.link/q4durx"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gold hover:text-gold/80 transition-colors inline-flex items-center gap-1"
              >
                <MessageCircle size={16} />
                Chat with us on WhatsApp
              </a>
            </p>
          </>
        )}
      </div>
    </div>
  )
}

export default function OrderConfirmedPage() {
  return (
    <ShopLayout>
      <Suspense fallback={
        <div className="min-h-screen flex items-center justify-center py-20 bg-cream-warm">
          <div className="animate-spin border-2 border-gold border-t-transparent rounded-full w-8 h-8" />
        </div>
      }>
        <OrderConfirmedContent />
      </Suspense>
    </ShopLayout>
  )
}
