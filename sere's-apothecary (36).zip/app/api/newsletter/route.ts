import { NextRequest, NextResponse } from 'next/server'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email || !email.includes('@')) {
      return NextResponse.json(
        { error: 'Valid email required' },
        { status: 400 }
      )
    }

    const RESEND_API_KEY = process.env.RESEND_API_KEY

    if (!RESEND_API_KEY) {
      return NextResponse.json(
        { error: 'Email service not configured' },
        { status: 500 }
      )
    }

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: "Sere's Apothecary <onboarding@resend.dev>",
        to: [email],
        subject: "Welcome to Sere's Apothecary ✦",
        html: `
<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#FAF7F2;font-family:Georgia,serif;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center" style="padding:40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0"
          style="background:#fff;border:1px solid #e8e0d0;max-width:600px;width:100%;">
          <tr>
            <td style="background:#2C1810;padding:36px;text-align:center;">
              <p style="margin:0;font-size:11px;letter-spacing:4px;
                color:#C9A84C;text-transform:uppercase;">
                Sere's Apothecary
              </p>
              <h1 style="margin:8px 0 0;font-size:24px;font-weight:300;
                color:#F5F0E8;letter-spacing:1px;">
                Welcome to the Inner Circle
              </h1>
            </td>
          </tr>
          <tr>
            <td style="padding:40px 36px;">
              <p style="color:#2C1810;font-size:16px;margin:0 0 16px;">
                Thank you for subscribing.
              </p>
              <p style="color:#5a4a3a;font-size:15px;line-height:1.7;
                margin:0 0 24px;">
                You are now part of an exclusive circle that gets 
                first access to new arrivals, private offers, and 
                curated fragrance stories from Sere's Apothecary.
              </p>
              <p style="color:#5a4a3a;font-size:15px;line-height:1.7;
                margin:0 0 32px;">
                Expect only the finest — no spam, ever.
              </p>
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center">
                    <a href="https://seresapothecary.vercel.app"
                      style="display:inline-block;background:#C9A84C;
                        color:#2C1810;padding:14px 36px;
                        font-family:Georgia,serif;font-size:12px;
                        letter-spacing:3px;text-transform:uppercase;
                        text-decoration:none;font-weight:600;">
                      Explore Collection
                    </a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="background:#1A0F0A;padding:20px;text-align:center;">
              <p style="margin:0 0 8px;font-size:11px;
                color:#7a6a5a;letter-spacing:2px;">
                © 2026 SERE'S APOTHECARY · BENIN CITY, NIGERIA
              </p>
              <p style="margin:0;font-size:11px;color:#7a6a5a;">
                <a href="https://wa.link/q4durx"
                  style="color:#C9A84C;text-decoration:none;">
                  Chat with us on WhatsApp
                </a>
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`,
      }),
    })

    if (!res.ok) {
      const error = await res.text()
      console.error('Resend error:', error)
      return NextResponse.json(
        { error: 'Failed to send email' },
        { status: 500 }
      )
    }

    return NextResponse.json({ success: true })

  } catch (error) {
    console.error('Newsletter error:', error)
    return NextResponse.json(
      { error: 'Something went wrong' },
      { status: 500 }
    )
  }
}
