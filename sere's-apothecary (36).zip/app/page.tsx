"use client";

import ShopLayout from "@/components/ShopLayout";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import {
  motion,
  useScroll,
  useTransform,
  useInView,
  useMotionValue,
} from "framer-motion";
import { useRef, useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  MessageCircle,
  Phone,
  ArrowRight,
  Heart,
  ShoppingBag,
} from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";

function NewsletterSection() {
  const [newsletterEmail, setNewsletterEmail] = 
    useState('')
  const [newsletterStatus, setNewsletterStatus] = 
    useState<'idle'|'loading'|'success'|'error'>('idle')
  const [newsletterError, setNewsletterError] = 
    useState('')

  const handleNewsletterSubmit = async () => {
    if (!newsletterEmail.trim()) return
    if (!newsletterEmail.includes('@')) {
      setNewsletterError('Please enter a valid email.')
      return
    }

    setNewsletterStatus('loading')
    setNewsletterError('')

    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email: newsletterEmail.trim() 
        }),
      })

      const data = await res.json()

      if (data.success) {
        setNewsletterStatus('success')
        setNewsletterEmail('')
      } else {
        setNewsletterStatus('error')
        setNewsletterError(
          data.error || 'Something went wrong. Try again.'
        )
      }
    } catch {
      setNewsletterStatus('error')
      setNewsletterError('Something went wrong. Try again.')
    }
  }

  return (
    <section className="bg-brown py-24 px-4">
      <div className="max-w-xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          <p className="font-accent text-gold/60 text-xs 
            tracking-[0.4em] uppercase mb-4">
            Stay in the Know
          </p>
          <h2 className="font-display text-cream 
            text-4xl font-light mb-4">
            Join the Inner Circle
          </h2>
          <p className="font-body text-cream/50 mb-10 
            leading-relaxed">
            Be first to discover new arrivals, exclusive 
            offers, and curated fragrance stories. 
            No spam — ever.
          </p>

          {newsletterStatus === 'success' ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="border border-gold/30 
                bg-gold/10 px-6 py-5"
            >
              <p className="font-display text-gold 
                text-xl mb-2">
                Welcome to the circle ✦
              </p>
              <p className="font-body text-cream/50 
                text-sm">
                Check your inbox for a welcome message.
              </p>
            </motion.div>
          ) : (
            <div className="space-y-3">
              <div className="flex flex-col 
                sm:flex-row gap-3">
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => {
                    setNewsletterEmail(e.target.value)
                    setNewsletterError('')
                    setNewsletterStatus('idle')
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') 
                      handleNewsletterSubmit()
                  }}
                  placeholder="Your email address"
                  style={{
                    backgroundColor: 
                      'rgba(245,240,232,0.05)',
                    border: 
                      '1px solid rgba(201,168,76,0.2)',
                    color: '#F5F0E8',
                  }}
                  className="flex-1 px-5 py-3 
                    font-body text-sm focus:outline-none 
                    placeholder:text-cream/20"
                />
                <button
                  onClick={handleNewsletterSubmit}
                  disabled={
                    newsletterStatus === 'loading' || 
                    !newsletterEmail.trim()
                  }
                  style={{
                    backgroundColor: '#C9A84C',
                    color: '#2C1810',
                    padding: '12px 28px',
                    fontFamily: 'Georgia, serif',
                    letterSpacing: '0.2em',
                    fontSize: '12px',
                    textTransform: 'uppercase',
                    fontWeight: '600',
                    border: 'none',
                    cursor: 
                      newsletterStatus === 'loading' || 
                      !newsletterEmail.trim()
                        ? 'not-allowed' 
                        : 'pointer',
                    opacity: 
                      newsletterStatus === 'loading' || 
                      !newsletterEmail.trim() 
                        ? 0.6 : 1,
                    whiteSpace: 'nowrap',
                  }}
                >
                  {newsletterStatus === 'loading' 
                    ? 'Subscribing...' 
                    : 'Subscribe'}
                </button>
              </div>

              {newsletterError && (
                <p className="font-body text-red-400 
                  text-xs text-left">
                  {newsletterError}
                </p>
              )}

              {newsletterStatus === 'error' && 
               !newsletterError && (
                <p className="font-body text-red-400 
                  text-xs text-left">
                  Something went wrong. Please try again.
                </p>
              )}
            </div>
          )}
        </motion.div>
      </div>
    </section>
  )
}

const formatPrice = (amount: number) => {
  return `₦${amount.toLocaleString("en-NG", { minimumFractionDigits: 2 })}`;
};

function TiltCard({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useTransform(y, [-100, 100], [8, -8]);
  const rotateY = useTransform(x, [-100, 100], [-8, 8]);
  const glare = useTransform(x, [-100, 100], [0, 1]);

  const requestRef = useRef<number | null>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const { clientX, clientY } = e;

    if (requestRef.current !== null) {
      cancelAnimationFrame(requestRef.current);
    }

    requestRef.current = requestAnimationFrame(() => {
      if (!cardRef.current) return;
      const rect = cardRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      x.set(clientX - centerX);
      y.set(clientY - centerY);
    });
  };

  const handleMouseLeave = () => {
    if (requestRef.current !== null) {
      cancelAnimationFrame(requestRef.current);
    }
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: "preserve-3d",
        perspective: 1000,
      }}
      className={className}
    >
      {/* Glare overlay */}
      <motion.div
        className="absolute inset-0 rounded-sm pointer-events-none z-10"
        style={{
          background: useTransform(
            glare,
            [0, 1],
            [
              "radial-gradient(circle at 0% 50%, rgba(201,168,76,0) 0%, transparent 60%)",
              "radial-gradient(circle at 100% 50%, rgba(201,168,76,0.12) 0%, transparent 60%)",
            ],
          ),
        }}
      />
      {children}
    </motion.div>
  );
}

export default function Home() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });

  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const textY = useTransform(scrollYProgress, [0, 1], ["0%", "-20%"]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const bgScale = useTransform(scrollYProgress, [0, 1], [1.1, 1.0]);

  const featuredProducts = useQuery(api.products.getFeaturedProducts, {});
  const { addToCart } = useCart();
  const {
    items: wishlist,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
  } = useWishlist();

  const storyRef = useRef(null);
  const { scrollYProgress: storyScroll } = useScroll({
    target: storyRef,
    offset: ["start end", "end start"],
  });
  const storyImageY = useTransform(storyScroll, [0, 1], ["-10%", "10%"]);

  const quoteRef = useRef(null);
  const { scrollYProgress: quoteScroll } = useScroll({
    target: quoteRef,
    offset: ["start end", "end start"],
  });
  const quoteScale = useTransform(quoteScroll, [0.1, 0.5], [0.85, 1]);
  const quoteOpacity = useTransform(quoteScroll, [0.1, 0.4], [0, 1]);

  // Static particles for pure CSS animation (no hydration mismatch)
  const particles = [
    { width: "7px", height: "7px", left: "15%", top: "25%", duration: "6s", delay: "0s" },
    { width: "5px", height: "5px", left: "85%", top: "15%", duration: "5s", delay: "1s" },
    { width: "6px", height: "6px", left: "55%", top: "75%", duration: "7s", delay: "2s" },
    { width: "4px", height: "4px", left: "25%", top: "85%", duration: "4.5s", delay: "0.5s" },
    { width: "7px", height: "7px", left: "75%", top: "45%", duration: "6.5s", delay: "1.5s" },
    { width: "5px", height: "5px", left: "35%", top: "55%", duration: "5.5s", delay: "0.7s" },
    { width: "6px", height: "6px", left: "65%", top: "85%", duration: "7.2s", delay: "2.2s" },
    { width: "4px", height: "4px", left: "45%", top: "15%", duration: "4.8s", delay: "0.8s" },
    { width: "7px", height: "7px", left: "95%", top: "65%", duration: "6.1s", delay: "1.1s" },
    { width: "5px", height: "5px", left: "5%", top: "35%", duration: "5.2s", delay: "0.2s" },
  ];

  return (
    <ShopLayout>
      {/* SECTION 1 — CINEMATIC HERO */}
      <div
        ref={heroRef}
        className="relative min-h-screen overflow-hidden bg-brown-deep"
      >
        {/* Background Layer */}
        <motion.div
          style={{ y: bgY, scale: bgScale }}
          className="absolute inset-0"
        >
          <Image
            fill
            className="object-cover"
            src="https://i.pinimg.com/736x/50/b8/ac/50b8ac834b697ec78918c6cb83936fc0.jpg"
            alt="Atmospheric dark luxury"
            sizes="100vw"
            priority
            quality={90}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-brown-deep/60 via-brown/40 to-brown-deep/90" />
          <div className="absolute inset-0 bg-gradient-to-r from-brown-deep/50 via-transparent to-brown-deep/30" />
        </motion.div>

        {/* Floating Particles */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {particles.map((p, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-gold/20 blur-sm animate-float-particle"
              style={{
                width: p.width,
                height: p.height,
                left: p.left,
                top: p.top,
                animationDuration: p.duration,
                animationDelay: p.delay,
              }}
            />
          ))}
        </div>

        {/* Hero Content */}
        <div className="relative z-10 flex flex-col items-center justify-center min-h-screen pt-20">
          <motion.div
            style={{ y: textY, opacity: heroOpacity }}
            className="text-center px-4 max-w-4xl mx-auto w-full"
          >
            <motion.p
              initial={{ opacity: 0, letterSpacing: "0.1em" }}
              animate={{ opacity: 1, letterSpacing: "0.4em" }}
              transition={{
                duration: 1.5,
                ease: [0.25, 0.1, 0.25, 1],
                delay: 0.2,
              }}
              className="font-accent text-gold/70 text-xs tracking-[0.4em] uppercase mb-8"
            >
              Benin City, Nigeria · Est. 2024
            </motion.p>

            <div style={{ perspective: "800px" }}>
              {["The", "Art", "of", "Luxury", "Fragrance"].map(
                (word, index) => (
                  <motion.span
                    key={index}
                    initial={{ opacity: 0, y: 60, rotateX: -45 }}
                    animate={{ opacity: 1, y: 0, rotateX: 0 }}
                    transition={{
                      duration: 1,
                      delay: index * 0.15,
                      ease: [0.25, 0.1, 0.25, 1],
                    }}
                    className="font-display text-cream text-6xl md:text-8xl lg:text-9xl font-light leading-none inline-block mr-4 md:mr-5 mb-2"
                  >
                    {word}
                  </motion.span>
                ),
              )}
            </div>

            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 1.2, delay: 0.8 }}
              className="h-px bg-gradient-to-r from-transparent via-gold to-transparent w-48 mx-auto my-10"
            />

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.0 }}
              className="font-body text-cream/60 text-lg md:text-xl max-w-lg mx-auto mb-12 leading-relaxed tracking-wide"
            >
              Globally curated perfumes and skincare rituals, delivered to your
              door.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 }}
              className="flex gap-6 justify-center flex-wrap"
            >
              <Link
                href="/perfumes"
                className="relative overflow-hidden group btn-gold px-10 py-4 text-sm"
              >
                Explore Collection
                <span className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700 ease-out" />
              </Link>
              <a href="#story" className="btn-outline-gold px-10 py-4 text-sm">
                Our Story
              </a>
            </motion.div>
          </motion.div>

          {/* Scroll Indicator */}
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="absolute bottom-10 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2"
          >
            <span className="font-body text-cream/30 text-xs tracking-widest uppercase">
              Scroll
            </span>
            <div className="w-px h-12 bg-gradient-to-b from-gold/60 to-transparent" />
          </motion.div>
        </div>
      </div>

      {/* SECTION 2 — MARQUEE BANNER */}
      <div className="bg-gold py-3 overflow-hidden whitespace-nowrap flex border-y border-gold/50">
        <motion.div
          animate={{ x: [0, "-50%"] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="flex whitespace-nowrap"
        >
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex items-center">
              <span className="font-accent text-brown text-xs tracking-[0.3em] uppercase px-4">
                PERFUME <span className="text-brown/40 px-2">·</span> SKINCARE{" "}
                <span className="text-brown/40 px-2">·</span> LUXURY{" "}
                <span className="text-brown/40 px-2">·</span> CURATED{" "}
                <span className="text-brown/40 px-2">·</span> BENIN CITY{" "}
                <span className="text-brown/40 px-2">·</span> NIGERIA{" "}
                <span className="text-brown/40 px-2">·</span>
              </span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* SECTION 2.5 — ESSENCE / CATEGORIES */}
      <div className="bg-cream py-24 px-4 border-b border-gold/10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <p className="font-accent text-gold text-xs tracking-[0.4em] uppercase mb-4">
              Explore Our Realm
            </p>
            <h2 className="font-display text-brown text-4xl md:text-5xl font-light mb-4">
              The Collections
            </h2>
            <div className="w-16 h-px bg-gold mx-auto" />
          </div>

          <div className="grid md:grid-cols-2 gap-6 lg:gap-10">
            {/* Category: Perfumes */}
            <Link
              href="/perfumes"
              className="group relative h-[500px] overflow-hidden bg-brown-deep flex items-end p-10"
            >
              <Image
                src="https://i.pinimg.com/736x/1b/ae/4d/1bae4de17c9a37fc6271b27f08e184be.jpg"
                alt="Perfumes"
                fill
                className="object-cover opacity-60 group-hover:scale-105 transition-transform duration-1000 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brown-deep via-transparent to-transparent opacity-80" />
              <div className="relative z-10 w-full">
                <p className="font-accent text-gold text-xs tracking-[0.3em] uppercase mb-3">
                  Signature Scents
                </p>
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-cream text-3xl md:text-4xl">
                    Perfumes
                  </h3>
                  <div className="w-10 h-10 rounded-full border border-gold/30 flex items-center justify-center group-hover:bg-gold group-hover:border-gold transition-colors duration-500">
                    <ArrowRight size={16} className="text-gold group-hover:text-brown transition-colors" />
                  </div>
                </div>
              </div>
            </Link>

            {/* Category: Skincare */}
            <Link
              href="/skincare"
              className="group relative h-[500px] overflow-hidden bg-brown-deep flex items-end p-10"
            >
              <Image
                src="https://i.pinimg.com/736x/17/a6/e8/17a6e89c804d8ca1456beb00cae13d22.jpg"
                alt="Skincare"
                fill
                className="object-cover opacity-60 group-hover:scale-105 transition-transform duration-1000 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brown-deep via-transparent to-transparent opacity-80" />
              <div className="relative z-10 w-full">
                <p className="font-accent text-gold text-xs tracking-[0.3em] uppercase mb-3">
                  Radiant Rituals
                </p>
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-cream text-3xl md:text-4xl">
                    Skincare
                  </h3>
                  <div className="w-10 h-10 rounded-full border border-gold/30 flex items-center justify-center group-hover:bg-gold group-hover:border-gold transition-colors duration-500">
                    <ArrowRight size={16} className="text-gold group-hover:text-brown transition-colors" />
                  </div>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </div>

      {/* SECTION 3 — FEATURED PRODUCTS */}
      <div className="bg-cream-warm py-24 px-4 overflow-hidden">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-center mb-16"
        >
          <p className="font-accent text-gold text-xs tracking-[0.4em] uppercase mb-4">
            Featured
          </p>
          <h2 className="font-display text-brown text-4xl md:text-5xl font-light mb-4">
            Handpicked for You
          </h2>
          <div className="w-16 h-px bg-gold mx-auto" />
        </motion.div>

        <div className="max-w-7xl mx-auto">
          {!featuredProducts ? (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {[...Array(4)].map((_, i) => (
                <div
                  key={i}
                  className="bg-cream relative aspect-[3/4] overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-cream via-cream-warm to-cream bg-[length:200%_100%] animate-pulse" />
                </div>
              ))}
            </div>
          ) : featuredProducts.length === 0 ? (
            <div className="text-center py-16">
              <p className="font-accent text-gold/40 text-xs tracking-[0.3em] uppercase mb-4">Coming Soon</p>
              <p className="font-display text-brown/40 text-2xl font-light">
                Featured products will appear here
              </p>
              <p className="font-body text-brown/30 text-sm mt-3">
                Mark products as featured in the admin panel to display them here.
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 md:gap-8">
                {featuredProducts.slice(0, 8).map((product) => {
                  const safeImageUrl = product.images?.[0] || null;
                  const isWishlisted = isInWishlist(product._id);
                  const handleWishlistToggle = (e: React.MouseEvent) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (isWishlisted) removeFromWishlist(product._id);
                    else
                      addToWishlist({
                        id: product._id,
                        name: product.name,
                        price: (product.priceKobo || 0) / 100,
                        imageUrl: safeImageUrl || "",
                        category: product.category,
                      });
                  };
                  return (
                    <TiltCard key={product._id} className="relative group">
                      <div className="bg-cream overflow-hidden relative">
                        <Link
                          href={`/product/${product._id}`}
                          className="block relative aspect-[3/4] overflow-hidden"
                        >
                          {safeImageUrl ? (
                            <Image
                              src={safeImageUrl}
                              alt={product.name}
                              fill
                              sizes="(max-width: 768px) 50vw, 25vw"
                              className="object-cover group-hover:scale-105 transition duration-700 ease-out"
                            />
                          ) : (
                            <div className="absolute inset-0 bg-cream-warm flex items-center justify-center">
                              <span className="font-accent text-xs text-brown/20 tracking-widest uppercase">No Image</span>
                            </div>
                          )}
                          <div className="absolute top-3 left-3 bg-brown-deep/80 backdrop-blur-sm font-accent text-gold text-[10px] tracking-widest uppercase px-3 py-1 z-10">
                            {(product.category || 'product').toUpperCase()}
                          </div>
                          <button
                            onClick={handleWishlistToggle}
                            className="absolute top-3 right-3 bg-cream/90 backdrop-blur-sm rounded-full p-2 hover:scale-110 transition-transform z-20"
                          >
                            <Heart
                              size={16}
                              className={
                                isWishlisted
                                  ? "text-gold fill-gold"
                                  : "text-brown/40 hover:text-gold transition-colors"
                              }
                            />
                          </button>
                        </Link>

                        <div className="p-5">
                          <Link href={`/product/${product._id}`}>
                            <h3 className="font-display text-brown text-lg leading-snug mb-2 hover:text-gold transition line-clamp-1">
                              {product.name}
                            </h3>
                          </Link>
                          <p className="font-body text-gold text-base mb-4">
                            {product.priceKobo && product.priceKobo > 0
                              ? formatPrice(product.priceKobo / 100)
                              : 'Price on request'}
                          </p>

                          <button
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              addToCart({
                                id: product._id,
                                name: product.name,
                                price: product.priceKobo ? product.priceKobo / 100 : 0,
                                quantity: 1,
                                imageUrl: safeImageUrl || "",
                                category: product.category,
                              });
                            }}
                            className="w-full py-3 border border-brown/10 font-accent text-xs tracking-widest uppercase text-brown/60 hover:bg-brown hover:text-gold hover:border-brown transition-all duration-300 flex items-center justify-center gap-2"
                          >
                            <ShoppingBag size={14} /> Add to Cart
                          </button>
                        </div>
                      </div>
                    </TiltCard>
                  );
                })}
              </div>
              <div className="mt-16 text-center">
                <Link href="/perfumes" className="btn-outline-gold inline-flex items-center gap-3 px-8 py-4">
                  View All Products <ArrowRight size={16} />
                </Link>
              </div>
            </>
          )}
        </div>
      </div>

      {/* SECTION 4 — CINEMATIC BRAND STORY */}
      <div id="story" className="bg-brown overflow-hidden">
        <div className="grid md:grid-cols-2">
          {/* Left Panel */}
          <div
            ref={storyRef}
            className="relative overflow-hidden min-h-[60vh] md:min-h-[80vh]"
          >
            <motion.div
              style={{ y: storyImageY }}
              className="absolute inset-[-10%]"
            >
              <Image
                src="https://i.pinimg.com/736x/aa/59/f9/aa59f9eb8ea7db0feb8871d214a3de2f.jpg"
                alt="Luxury perfume flat-lay"
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-brown/80 mix-blend-overlay" />
            </motion.div>
          </div>

          {/* Right Panel */}
          <div className="flex items-center justify-center p-12 md:p-16 lg:p-24 relative bg-brown">
            {/* Soft gradient from left */}
            <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-brown to-transparent hidden md:block" />

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
              variants={{
                hidden: { opacity: 0 },
                visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
              }}
              className="max-w-xl relative z-10"
            >
              <motion.p
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
                className="font-accent text-gold/60 text-xs tracking-[0.4em] uppercase mb-6"
              >
                Our Story
              </motion.p>

              <motion.h2
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
                className="font-display text-cream text-4xl md:text-5xl lg:text-6xl font-light leading-tight mb-8"
              >
                Curating the World&apos;s Finest
              </motion.h2>

              <motion.div
                variants={{ hidden: { scaleX: 0 }, visible: { scaleX: 1 } }}
                transition={{ duration: 1 }}
                className="w-12 h-px bg-gold mb-8 origin-left"
              />

              <motion.p
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
                className="font-body text-cream/70 leading-relaxed mb-6 text-base lg:text-lg"
              >
                Sere&apos;s Apothecary was born from a desire to bring
                unparalleled olfactory and skincare experiences to the heart of
                Benin City. We comb the globe for artisanal perfumers and
                scientifically proven formulations.
              </motion.p>

              <motion.p
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
                className="font-body text-cream/70 leading-relaxed mb-12 text-base lg:text-lg"
              >
                Everything in our collection must earn its place. Nothing is
                mass-market. Everything is a masterpiece.
              </motion.p>

              <motion.div
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
                className="grid grid-cols-3 gap-8 mb-12 border-t border-gold/10 pt-10"
              >
                <div>
                  <p className="font-display text-4xl text-gold mb-2">200<span className="text-2xl">+</span></p>
                  <p className="font-body text-xs text-cream/40 tracking-widest uppercase">
                    Products
                  </p>
                </div>
                <div>
                  <p className="font-display text-4xl text-gold mb-2">2</p>
                  <p className="font-body text-xs text-cream/40 tracking-widest uppercase">
                    Categories
                  </p>
                </div>
                <div>
                  <p className="font-display text-4xl text-gold mb-2">100<span className="text-2xl">%</span></p>
                  <p className="font-body text-xs text-cream/40 tracking-widest uppercase">
                    Curated
                  </p>
                </div>
              </motion.div>

              <motion.div
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 },
                }}
              >
                <Link
                  href="/perfumes"
                  className="btn-gold inline-flex items-center gap-3 py-4 px-10 text-sm tracking-widest"
                >
                  Discover Collection <ArrowRight size={16} />
                </Link>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* SECTION 5 — FULL-WIDTH QUOTE */}
      <div className="bg-cream-warm py-32 px-4 relative overflow-hidden">
        {/* Subtle background decoration */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/3" />

        <div
          className="text-center max-w-4xl mx-auto relative z-10"
          ref={quoteRef}
        >
          <motion.div style={{ scale: quoteScale, opacity: quoteOpacity }}>
            <p className="font-display text-8xl text-gold/20 leading-none mb-[-2rem]">
              &quot;
            </p>
            <p className="font-display text-brown text-2xl md:text-4xl font-light leading-relaxed italic mb-8">
              Scent is the most powerful trigger of memory and emotion. We
              curate only what moves you.
            </p>
            <p className="font-accent text-gold/60 text-xs tracking-[0.3em] uppercase">
              — Sere&apos;s Apothecary
            </p>
          </motion.div>
        </div>
      </div>

      {/* SECTION 5.5 — NEWSLETTER */}
      <NewsletterSection />

      {/* SECTION 6 — INSTAGRAM GRID */}
      <div className="bg-brown py-20 px-4">
        <div className="text-center mb-12">
          <h2 className="font-display text-cream text-3xl">
            Follow Our Journey
          </h2>
          <a
            href="#"
            className="inline-block font-accent text-gold/60 text-xs tracking-widest mt-2 hover:text-gold transition-colors"
          >
            @seresapothecary
          </a>
        </div>

        <div className="max-w-4xl mx-auto grid grid-cols-2 lg:grid-cols-3 gap-0">
          {[
            "https://i.pinimg.com/736x/ca/f6/5b/caf65b29f21242adc943007a7a3fbdc6.jpg",
            "https://i.pinimg.com/736x/e3/f0/41/e3f041b39ec6bbf69e0a772be88907fe.jpg",
            "https://i.pinimg.com/1200x/05/80/e0/0580e0eb80a53cd3b6f5a8a93ec4b5ce.jpg",
            "https://i.pinimg.com/736x/17/a6/e8/17a6e89c804d8ca1456beb00cae13d22.jpg",
            "https://i.pinimg.com/1200x/cb/06/9d/cb069d46828e7845534f5b45a1ffad18.jpg",
            "https://i.pinimg.com/736x/d6/f9/48/d6f948c04796f64f494a55516a4b5622.jpg",
          ].map((url, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.6 }}
              className="relative aspect-square overflow-hidden cursor-pointer group bg-brown-deep"
            >
              <Image
                src={url}
                alt="Instagram content"
                fill
                sizes="(max-width: 768px) 50vw, 33vw"
                className="object-cover group-hover:scale-110 transition duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-brown/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition duration-300">
                <span className="text-gold text-2xl font-serif">♦</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* FLOATING SUPPORT BUTTONS */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-3">
        <div className="relative">
          <span className="absolute inset-0 rounded-full border-2 border-green-500 opacity-30 animate-ping" />
          <motion.a
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.95 }}
            href="https://wa.link/q4durx"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center rounded-full bg-green-500 hover:bg-green-600 p-4 shadow-2xl text-white transition-colors relative z-10"
            title="Chat on WhatsApp"
          >
            <MessageCircle size={20} />
          </motion.a>
        </div>

        <div className="relative">
          <span className="absolute inset-0 rounded-full border-2 border-gold opacity-30 animate-ping" />
          <motion.a
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.95 }}
            href="tel:+2347044579258"
            className="flex items-center justify-center rounded-full bg-gold hover:bg-yellow-500 p-4 shadow-2xl text-brown transition-colors relative z-10"
            title="Call Us"
          >
            <Phone size={20} />
          </motion.a>
        </div>
      </div>
    </ShopLayout>
  );
}
