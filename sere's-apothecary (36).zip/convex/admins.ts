import { mutation, query } from "./_generated/server"
import { v } from "convex/values"
import { Id } from "./_generated/dataModel"

export type AdminTokenPayload = {
  adminId: string
  email: string
  role: "master" | "sub"
}

const _JWT_SECRET = process.env.JWT_SECRET
if (!_JWT_SECRET) {
  throw new Error(
    "CRITICAL: JWT_SECRET environment variable is not set. " +
    "Set it in your Convex dashboard under Settings → " +
    "Environment Variables before proceeding."
  )
}
export const JWT_SECRET: string = _JWT_SECRET

// ── Web Crypto API Helpers (PBKDF2 & HMAC-SHA256) ──

async function hashPassword(password: string): Promise<string> {
  const enc = new TextEncoder()
  const keyMaterial = await crypto.subtle.importKey(
    "raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]
  )
  const salt = crypto.getRandomValues(new Uint8Array(16))
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    keyMaterial, 256
  )
  const saltHex = Array.from(salt)
    .map(b => b.toString(16).padStart(2, "0")).join("")
  const hashHex = Array.from(new Uint8Array(bits))
    .map(b => b.toString(16).padStart(2, "0")).join("")
  return saltHex + ":" + hashHex
}

async function verifyPassword(
  password: string, stored: string
): Promise<boolean> {
  const [saltHex, storedHash] = stored.split(":")
  if (!saltHex || !storedHash) return false
  const salt = new Uint8Array(
    saltHex.match(/.{2}/g)!.map(b => parseInt(b, 16))
  )
  const enc = new TextEncoder()
  const keyMaterial = await crypto.subtle.importKey(
    "raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]
  )
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
    keyMaterial, 256
  )
  const hashHex = Array.from(new Uint8Array(bits))
    .map(b => b.toString(16).padStart(2, "0")).join("")
  return hashHex === storedHash
}

async function signToken(
  payload: AdminTokenPayload, secret: string
): Promise<string> {
  const enc = new TextEncoder()
  const header = btoa(JSON.stringify({ alg: "HS256", typ: "JWT" }))
    .replace(/=/g, "")
  const body = btoa(JSON.stringify({
    ...payload,
    exp: Math.floor(Date.now() / 1000) + 8 * 3600
  })).replace(/=/g, "")
  const sigInput = header + "." + body
  const key = await crypto.subtle.importKey(
    "raw", enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  )
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(sigInput))
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)))
    .replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "")
  return sigInput + "." + sigB64
}

export async function verifyToken(
  token: string, secret: string
): Promise<AdminTokenPayload | null> {
  try {
    const parts = token.split(".")
    if (parts.length !== 3) return null
    const [header, body, sig] = parts
    const enc = new TextEncoder()
    const key = await crypto.subtle.importKey(
      "raw", enc.encode(secret),
      { name: "HMAC", hash: "SHA-256" }, false, ["verify"]
    )
    const sigBytes = Uint8Array.from(
      atob(sig.replace(/-/g, "+").replace(/_/g, "/")),
      c => c.charCodeAt(0)
    )
    const valid = await crypto.subtle.verify(
      "HMAC", key, sigBytes, enc.encode(header + "." + body)
    )
    if (!valid) return null
    const decoded = JSON.parse(atob(body)) as AdminTokenPayload & { exp: number }
    if (decoded.exp < Math.floor(Date.now() / 1000)) return null
    return { adminId: decoded.adminId, email: decoded.email, role: decoded.role }
  } catch {
    return null
  }
}

// ── Mutations & Queries ──

export const seedMasterAdmin = mutation({
  args: {},
  handler: async (ctx) => {
    const masterEmail = process.env.MASTER_ADMIN_EMAIL || "boluwatifeayodeji60@gmail.com"
    const masterPassword = process.env.MASTER_ADMIN_PASSWORD
    if (!masterPassword) {
      throw new Error("MASTER_ADMIN_PASSWORD environment variable is not set")
    }

    const existingAdmins = await ctx.db
      .query("admins")
      .filter((q) => q.eq(q.field("email"), masterEmail))
      .collect()

    if (existingAdmins.length > 0) {
      return { seeded: false }
    }

    const passwordHash = await hashPassword(masterPassword)
    await ctx.db.insert("admins", {
      email: masterEmail,
      passwordHash: passwordHash,
      role: "master",
      isActive: true,
      createdAt: Date.now()
    })

    return { seeded: true }
  }
})

export const loginAdmin = mutation({
  args: {
    email: v.string(),
    password: v.string(),
  },
  handler: async (ctx, args) => {
    const now = Date.now()
    const attemptRecord = await ctx.db
      .query("loginAttempts")
      .withIndex("by_email", (q) => q.eq("email", args.email))
      .first()

    if (attemptRecord && attemptRecord.lockedUntil > now) {
      throw new Error("Too many failed attempts. Account locked temporarily.")
    }

    const setFailed = async () => {
      const attempts = attemptRecord ? attemptRecord.attempts + 1 : 1
      const lockedUntil = attempts >= 5 ? now + 15 * 60 * 1000 : 0
      if (attemptRecord) {
        await ctx.db.patch(attemptRecord._id, { attempts, lockedUntil })
      } else {
        await ctx.db.insert("loginAttempts", { email: args.email, attempts, lockedUntil })
      }
    }

    const admins = await ctx.db
      .query("admins")
      .withIndex("by_email", (q) => q.eq("email", args.email))
      .collect()

    const admin = admins[0]
    if (!admin) {
      await setFailed()
      throw new Error("Invalid credentials")
    }

    if (admin.isActive === false) {
      throw new Error("Invalid credentials")
    }

    const isValid = await verifyPassword(args.password, admin.passwordHash)
    if (!isValid) {
      await setFailed()
      throw new Error("Invalid credentials")
    }

    if (attemptRecord) {
      await ctx.db.patch(attemptRecord._id, { attempts: 0, lockedUntil: 0 })
    }

    const token = await signToken(
      { adminId: admin._id, email: admin.email, role: admin.role as "master" | "sub" },
      JWT_SECRET
    )

    return {
      token,
      role: admin.role,
      email: admin.email
    }
  }
})

export const verifyAdminSession = query({
  args: {
    token: v.string()
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET)
    if (!payload) return null

    const admin = await ctx.db.get(payload.adminId as Id<"admins">)
    if (!admin) return null
    if (admin.isActive === false) return null

    return {
      adminId: payload.adminId,
      email: admin.email,
      role: admin.role as "master" | "sub"
    }
  }
})

export const provisionSubAdmin = mutation({
  args: {
    token: v.string(),
    email: v.string(),
    password: v.string()
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET)
    if (!payload || payload.role !== "master") {
      throw new Error("Unauthorized")
    }

    const existingAdmins = await ctx.db
      .query("admins")
      .filter((q) => q.eq(q.field("email"), args.email))
      .collect()

    if (existingAdmins.length > 0) {
      throw new Error("An admin with this email already exists")
    }

    const passwordHash = await hashPassword(args.password)
    await ctx.db.insert("admins", {
      email: args.email,
      passwordHash: passwordHash,
      role: "sub",
      isActive: true,
      createdBy: payload.adminId,
      createdAt: Date.now()
    })

    return { success: true }
  }
})

export const deactivateAdmin = mutation({
  args: {
    token: v.string(),
    targetAdminId: v.string()
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET)
    if (!payload || payload.role !== "master") {
      throw new Error("Unauthorized")
    }

    const targetAdmin = await ctx.db.get(args.targetAdminId as Id<"admins">)
    if (!targetAdmin) throw new Error("Admin not found")
    
    if (targetAdmin.role === "master") {
      throw new Error("Cannot deactivate master")
    }

    await ctx.db.patch(args.targetAdminId as Id<"admins">, { isActive: false })
    return { success: true }
  }
})

export const listSubAdmins = query({
  args: {
    token: v.string()
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET)
    if (!payload || payload.role !== "master") {
      throw new Error("Unauthorized")
    }

    const allAdmins = await ctx.db.query("admins").collect()
    const subAdmins = allAdmins.filter(a => a.role === "sub")

    return subAdmins.map(a => ({
      _id: a._id,
      email: a.email,
      isActive: a.isActive !== false,
      createdAt: a.createdAt
    }))
  }
})

export const changePassword = mutation({
  args: {
    token: v.string(),
    currentPassword: v.string(),
    newPassword: v.string()
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET)
    if (!payload) throw new Error("Unauthorized")

    const admin = await ctx.db.get(payload.adminId as Id<"admins">)
    if (!admin) throw new Error("Admin not found")

    const isValid = await verifyPassword(args.currentPassword, admin.passwordHash)
    if (!isValid) {
      throw new Error("Current password is incorrect")
    }

    const passwordHash = await hashPassword(args.newPassword)
    await ctx.db.patch(payload.adminId as Id<"admins">, { passwordHash: passwordHash })

    return { success: true }
  }
})
