import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { verifyToken, JWT_SECRET } from "./admins";

export const createOrder = mutation({
  args: {
    customerName: v.string(),
    customerEmail: v.string(),
    customerPhone: v.string(),
    deliveryAddress: v.string(),
    deliveryCity: v.string(),
    deliveryState: v.string(),
    items: v.array(
      v.object({
        productId: v.string(),
        name: v.string(),
        priceKobo: v.number(),
        qty: v.number(),
        imageUrl: v.string(),
      })
    ),
    subtotalKobo: v.number(),
    discountKobo: v.number(),
    paystackReference: v.string(),
  },
  handler: async (ctx, args) => {
    // Prevent duplicate orders for the same Paystack transaction
    const existingOrder = await ctx.db
      .query("orders")
      .withIndex("by_paystackReference", (q) => q.eq("paystackReference", args.paystackReference))
      .first();

    if (existingOrder) {
      return { orderId: existingOrder._id, trackingCode: existingOrder.trackingCode };
    }

    const randomCode = Math.random().toString(36).substring(2, 6).toUpperCase();
    const trackingCode = `SA-${randomCode}-2026`;
    
    const now = Date.now();
    const orderId = await ctx.db.insert("orders", {
      ...args,
      trackingCode,
      paystackStatus: "pending",
      fulfillmentStatus: "processing",
      createdAt: now,
      updatedAt: now,
    });
    
    return { orderId, trackingCode };
  },
});

export const getOrderByTracking = query({
  args: { trackingCode: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("orders")
      .withIndex("by_trackingCode", (q) => q.eq("trackingCode", args.trackingCode))
      .first();
  },
});

export const listOrders = query({
  args: {
    token: v.string(),
    fulfillmentStatus: v.optional(v.union(
      v.literal("processing"),
      v.literal("shipped"),
      v.literal("delivered"),
      v.literal("cancelled")
    )),
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");

    let orders = await ctx.db.query("orders").collect();
    
    if (args.fulfillmentStatus) {
      orders = orders.filter((o) => o.fulfillmentStatus === args.fulfillmentStatus);
    }
    
    return orders.sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0));
  },
});

export const updateFulfillmentStatus = mutation({
  args: {
    token: v.string(),
    orderId: v.string(),
    fulfillmentStatus: v.union(
      v.literal("processing"),
      v.literal("shipped"),
      v.literal("delivered"),
      v.literal("cancelled")
    ),
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");

    const orderId = ctx.db.normalizeId("orders", args.orderId);
    if (!orderId) throw new Error("Invalid order ID");
    await ctx.db.patch(orderId, {
      fulfillmentStatus: args.fulfillmentStatus,
      updatedAt: Date.now(),
    });
  },
});
