import { httpRouter } from "convex/server";
import { httpAction } from "./_generated/server";
import { api } from "./_generated/api";

const http = httpRouter();

// ── Web Crypto helper for Paystack HMAC-SHA512 ───────────
async function verifyPaystackSignature(body: string, signature: string, secret: string) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-512" },
    false,
    ["sign"]
  );
  
  const signatureBuffer = await crypto.subtle.sign("HMAC", key, enc.encode(body));
  const signatureHex = Array.from(new Uint8Array(signatureBuffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
    
  return signatureHex === signature;
}

// ── Paystack webhook ─────────────────────────────────────
http.route({
  path: "/paystack/webhook",
  method: "POST",
  handler: httpAction(async (ctx, request) => {

    // 1. Read raw body as text for signature verification
    const rawBody = await request.text();

    // 2. Verify HMAC-SHA512 signature
    const paystackSignature = request.headers.get("x-paystack-signature");
    const secretKey = process.env.PAYSTACK_SECRET_KEY;

    if (!secretKey) {
      console.error("PAYSTACK_SECRET_KEY not set in Convex environment");
      return new Response("Server misconfiguration", { status: 500 });
    }

    if (!paystackSignature) {
      return new Response("Missing signature", { status: 401 });
    }

    const isValid = await verifyPaystackSignature(rawBody, paystackSignature, secretKey);

    if (!isValid) {
      console.error("Webhook signature mismatch — possible spoofed request");
      return new Response("Invalid signature", { status: 401 });
    }

    // 3. Parse the verified body
    let event: PaystackEvent;
    try {
      event = JSON.parse(rawBody);
    } catch {
      return new Response("Invalid JSON", { status: 400 });
    }

    // 4. Only process successful charge events
    if (event.event !== "charge.success") {
      return new Response("Event ignored", { status: 200 });
    }

    const data = event.data;

    // Verify transaction dynamically
    const verifyRes = await fetch(`https://api.paystack.co/transaction/verify/${data.reference}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${secretKey}`
      }
    });
    if (!verifyRes.ok) {
      console.error("Paystack verify API failed");
      return new Response("Verify failed", { status: 400 });
    }
    const verifyData = await verifyRes.json();
    if (!verifyData.status || verifyData.data.status !== "success") {
       return new Response("Not a successful transaction", { status: 400 });
    }

    const metadata = data.metadata ?? {};
    const items: OrderItem[] = metadata.items ?? [];
    
    // Calculate expected order total
    let expectedTotalKobo = 0;
    for (const item of items) {
      const product = await ctx.runQuery(api.products.getProduct, { id: item.productId as any });
      if (product) {
        expectedTotalKobo += product.priceKobo * item.qty;
      }
    }

    if (expectedTotalKobo > 0 && verifyData.data.amount < expectedTotalKobo) {
      console.error(`Amount mismatch: expected ${expectedTotalKobo}, got ${verifyData.data.amount}`);
      return new Response("Amount mismatch", { status: 400 });
    }

    const customerName: string = metadata.customerName ?? metadata.buyerName ?? data.customer.first_name ?? "Customer";
    const customerPhone: string = metadata.customerPhone ?? metadata.buyerPhone ?? data.customer.phone ?? "";
    const deliveryAddress: string = metadata.deliveryAddress ?? metadata.buyerAddress ?? "";
    // 6. Create order in Convex — this also generates tracking code
    const { orderId, trackingCode } = await ctx.runMutation(
      api.orders.createOrder,
      {
        customerName: customerName,
        customerEmail: data.customer.email,
        customerPhone: customerPhone,
        deliveryAddress: deliveryAddress,
        deliveryCity: metadata.deliveryCity ?? "",
        deliveryState: metadata.deliveryState ?? "",
        items: items.map(i => ({ ...i, imageUrl: i.imageUrl ?? "" })),
        subtotalKobo: verifyData.data.amount,
        discountKobo: 0,
        paystackReference: data.reference,
      }
    );

    // 7. Decrement stock for each item purchased
    for (const item of items) {
      try {
        await ctx.runMutation(api.products.decrementStock, {
          productId: item.productId as any,
          qty: item.qty,
        });
      } catch (err) {
        // Log but don't fail the webhook — order is already created
        console.error(`Stock decrement failed for ${item.productId}:`, err);
      }
    }

    // 8. Send emails via Resend
    const RESEND_API_KEY = process.env.RESEND_API_KEY;

    if (RESEND_API_KEY) {
      // Email to buyer
      await sendBuyerEmail({
        apiKey: RESEND_API_KEY,
        to: data.customer.email,
        customerName,
        trackingCode,
        items,
        subtotalKobo: data.amount,
        paystackReference: data.reference,
      });

      // Email to merchant
      await sendMerchantEmail({
        apiKey: RESEND_API_KEY,
        customerName,
        buyerEmail: data.customer.email,
        customerPhone,
       deliveryAddress,
        trackingCode,
        items,
        subtotalKobo: data.amount,
        paystackReference: data.reference,
      });
    } else {
      console.error("RESEND_API_KEY not set — emails not sent");
    }

    console.log(`Order created: ${orderId} | Tracking: ${trackingCode}`);
    return new Response("OK", { status: 200 });
  }),
});

export default http;

// ── Types ────────────────────────────────────────────────
interface OrderItem {
  productId: string;
  name: string;
  priceKobo: number;
  qty: number;
  imageUrl?: string;
}

interface PaystackEvent {
  event: string;
  data: {
    reference: string;
    amount: number;
    customer: {
      email: string;
      first_name?: string;
      phone?: string;
    };
    metadata?: {
      customerName?: string;
      customerPhone?: string;
      deliveryAddress?: string;
      buyerName?: string;
      buyerPhone?: string;
      buyerAddress?: string;
      deliveryCity?: string;
      deliveryState?: string;
      items?: OrderItem[];
    };
  };
}

// ── Email helpers ────────────────────────────────────────
async function sendBuyerEmail(params: {
  apiKey: string;
  to: string;
  customerName: string;
  trackingCode: string;
  items: OrderItem[];
  subtotalKobo: number;
  paystackReference: string;
}) {
  const itemRows = params.items
    .map(
      (item) =>
        `<tr>
          <td style="padding:8px 12px;border-bottom:1px solid #f0ebe0;
            font-family:Georgia,serif;color:#2C1810;">${item.name}</td>
          <td style="padding:8px 12px;border-bottom:1px solid #f0ebe0;
            text-align:center;color:#2C1810;">${item.qty}</td>
          <td style="padding:8px 12px;border-bottom:1px solid #f0ebe0;
            text-align:right;color:#2C1810;">
            ₦${((item.priceKobo * item.qty) / 100).toLocaleString("en-NG")}
          </td>
        </tr>`
    )
    .join("");

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#FAF7F2;font-family:Georgia,serif;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center" style="padding:40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0"
          style="background:#fff;border:1px solid #e8e0d0;max-width:600px;width:100%;">

          <!-- Header -->
          <tr>
            <td style="background:#2C1810;padding:36px;text-align:center;">
              <p style="margin:0;font-size:11px;letter-spacing:4px;
                color:#C9A84C;text-transform:uppercase;font-family:Georgia,serif;">
                Sere's Apothecary
              </p>
              <h1 style="margin:8px 0 0;font-size:28px;font-weight:300;
                color:#F5F0E8;font-family:Georgia,serif;letter-spacing:1px;">
                Order Confirmed
              </h1>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:40px 36px;">
              <p style="color:#2C1810;font-size:16px;margin:0 0 8px;">
                Dear ${params.customerName},
              </p>
              <p style="color:#5a4a3a;font-size:15px;line-height:1.6;margin:0 0 32px;">
                Thank you for your order. Your payment has been confirmed and 
                your items are being prepared.
              </p>

              <!-- Tracking code box -->
              <table width="100%" cellpadding="0" cellspacing="0"
                style="background:#FAF7F2;border:1px solid #C9A84C;margin-bottom:32px;">
                <tr>
                  <td style="padding:24px;text-align:center;">
                    <p style="margin:0 0 8px;font-size:11px;letter-spacing:3px;
                      color:#A8862F;text-transform:uppercase;">Your Tracking Code</p>
                    <p style="margin:0;font-size:28px;font-weight:600;
                      color:#2C1810;letter-spacing:4px;font-family:Georgia,serif;">
                      ${params.trackingCode}
                    </p>
                    <p style="margin:8px 0 0;font-size:13px;color:#7a6a5a;">
                      Use this code at seresapothecary.vercel.app/track
                    </p>
                  </td>
                </tr>
              </table>

              <!-- Order items -->
              <p style="font-size:11px;letter-spacing:3px;color:#A8862F;
                text-transform:uppercase;margin:0 0 12px;">Order Summary</p>
              <table width="100%" cellpadding="0" cellspacing="0"
                style="border:1px solid #f0ebe0;">
                <thead>
                  <tr style="background:#FAF7F2;">
                    <th style="padding:10px 12px;text-align:left;font-size:12px;
                      color:#7a6a5a;font-weight:normal;letter-spacing:1px;">Item</th>
                    <th style="padding:10px 12px;text-align:center;font-size:12px;
                      color:#7a6a5a;font-weight:normal;letter-spacing:1px;">Qty</th>
                    <th style="padding:10px 12px;text-align:right;font-size:12px;
                      color:#7a6a5a;font-weight:normal;letter-spacing:1px;">Price</th>
                  </tr>
                </thead>
                <tbody>${itemRows}</tbody>
                <tfoot>
                  <tr>
                    <td colspan="2" style="padding:12px;text-align:right;
                      font-size:13px;color:#7a6a5a;letter-spacing:1px;">
                      Product Subtotal
                    </td>
                    <td style="padding:12px;text-align:right;font-size:15px;
                      font-weight:600;color:#2C1810;">
                      ₦${(params.subtotalKobo / 100).toLocaleString("en-NG")}
                    </td>
                  </tr>
                </tfoot>
              </table>

              <!-- Delivery disclaimer -->
              <table width="100%" cellpadding="0" cellspacing="0"
                style="background:#fff8e8;border-left:3px solid #C9A84C;margin:24px 0;">
                <tr>
                  <td style="padding:14px 16px;font-size:13px;color:#5a4a2a;
                    line-height:1.5;">
                    <strong>Please note:</strong> The amount charged is strictly 
                    the product price. Delivery fee is NOT included and will be 
                    communicated to you separately.
                  </td>
                </tr>
              </table>

              <!-- Support -->
              <p style="font-size:14px;color:#5a4a3a;margin:0;">
                Questions? Reach us on 
                <a href="https://wa.link/q4durx" style="color:#C9A84C;">WhatsApp</a> 
                or call 
                <a href="tel:+2347044579258" style="color:#C9A84C;">+234 704 457 9258</a>.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#1A0F0A;padding:24px;text-align:center;">
              <p style="margin:0;font-size:11px;color:#7a6a5a;letter-spacing:2px;">
                © 2026 SERE'S APOTHECARY · BENIN CITY, NIGERIA
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

  await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${params.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: "Sere's Apothecary <onboarding@resend.dev>",

      to: [params.to],
      subject: `Order Confirmed — ${params.trackingCode} | Sere's Apothecary`,
      html,
    }),
  });
}

async function sendMerchantEmail(params: {
  apiKey: string;
  customerName: string;
  buyerEmail: string;
  customerPhone: string;
  deliveryAddress: string;
  trackingCode: string;
  items: OrderItem[];
  subtotalKobo: number;
  paystackReference: string;
}) {
  const itemList = params.items
    .map(
      (item) =>
        `<tr>
          <td style="padding:8px 12px;border-bottom:1px solid #f0ebe0;
            color:#2C1810;">${item.name}</td>
          <td style="padding:8px 12px;border-bottom:1px solid #f0ebe0;
            text-align:center;color:#2C1810;">${item.qty}</td>
          <td style="padding:8px 12px;border-bottom:1px solid #f0ebe0;
            text-align:right;color:#2C1810;">
            ₦${((item.priceKobo * item.qty) / 100).toLocaleString("en-NG")}
          </td>
        </tr>`
    )
    .join("");

  const html = `
<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#FAF7F2;font-family:Georgia,serif;">
  <table width="100%" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center" style="padding:40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0"
          style="background:#fff;border:1px solid #e8e0d0;max-width:600px;width:100%;">

          <tr>
            <td style="background:#2C1810;padding:28px 36px;">
              <p style="margin:0;font-size:11px;letter-spacing:4px;
                color:#C9A84C;text-transform:uppercase;">Sere's Apothecary</p>
              <h1 style="margin:6px 0 0;font-size:22px;font-weight:400;
                color:#F5F0E8;letter-spacing:1px;">
                💰 New Order Received
              </h1>
            </td>
          </tr>

          <tr>
            <td style="padding:32px 36px;">

              <!-- Tracking + reference -->
              <table width="100%" style="margin-bottom:28px;">
                <tr>
                  <td style="width:50%;padding-right:12px;">
                    <p style="margin:0 0 4px;font-size:11px;letter-spacing:2px;
                      color:#A8862F;text-transform:uppercase;">Tracking Code</p>
                    <p style="margin:0;font-size:20px;font-weight:600;
                      color:#2C1810;letter-spacing:3px;">${params.trackingCode}</p>
                  </td>
                  <td style="width:50%;padding-left:12px;">
                    <p style="margin:0 0 4px;font-size:11px;letter-spacing:2px;
                      color:#A8862F;text-transform:uppercase;">Paystack Ref</p>
                    <p style="margin:0;font-size:13px;color:#5a4a3a;
                      word-break:break-all;">${params.paystackReference}</p>
                  </td>
                </tr>
              </table>

              <!-- Buyer details -->
              <p style="margin:0 0 12px;font-size:11px;letter-spacing:2px;
                color:#A8862F;text-transform:uppercase;">Buyer Details</p>
              <table width="100%" style="background:#FAF7F2;margin-bottom:28px;">
                <tr>
                  <td style="padding:16px;">
                    <p style="margin:0 0 6px;color:#2C1810;font-size:15px;">
                      <strong>${params.customerName}</strong>
                    </p>
                    <p style="margin:0 0 4px;color:#5a4a3a;font-size:14px;">
                      ${params.buyerEmail}
                    </p>
                    <p style="margin:0 0 4px;color:#5a4a3a;font-size:14px;">
                      ${params.customerPhone}
                    </p>
                    <p style="margin:0;color:#5a4a3a;font-size:14px;">
                      ${params.deliveryAddress}
                    </p>
                  </td>
                </tr>
              </table>

              <!-- Items -->
              <p style="margin:0 0 12px;font-size:11px;letter-spacing:2px;
                color:#A8862F;text-transform:uppercase;">Items Ordered</p>
              <table width="100%" cellpadding="0" cellspacing="0"
                style="border:1px solid #f0ebe0;margin-bottom:16px;">
                <thead>
                  <tr style="background:#FAF7F2;">
                    <th style="padding:10px 12px;text-align:left;font-size:12px;
                      color:#7a6a5a;font-weight:normal;">Item</th>
                    <th style="padding:10px 12px;text-align:center;font-size:12px;
                      color:#7a6a5a;font-weight:normal;">Qty</th>
                    <th style="padding:10px 12px;text-align:right;font-size:12px;
                      color:#7a6a5a;font-weight:normal;">Price</th>
                  </tr>
                </thead>
                <tbody>${itemList}</tbody>
                <tfoot>
                  <tr>
                    <td colspan="2" style="padding:12px;text-align:right;
                      font-size:13px;color:#7a6a5a;">Total</td>
                    <td style="padding:12px;text-align:right;font-size:16px;
                      font-weight:600;color:#2C1810;">
                      ₦${(params.subtotalKobo / 100).toLocaleString("en-NG")}
                    </td>
                  </tr>
                </tfoot>
              </table>

            </td>
          </tr>

          <tr>
            <td style="background:#1A0F0A;padding:20px;text-align:center;">
              <p style="margin:0;font-size:11px;color:#7a6a5a;letter-spacing:2px;">
                SERE'S APOTHECARY — ADMIN NOTIFICATION
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

  await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${params.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
     from: "Sere's Apothecary <onboarding@resend.dev>",

      to: ["ediaeosasere@gmail.com"],
      subject: `New Order — ${params.trackingCode} — ₦${(params.subtotalKobo / 100).toLocaleString("en-NG")}`,
      html,
    }),
  });
}