import { v } from "convex/values";
import { query } from "./_generated/server";

async function verifyAdminSession(ctx: any, token: string) {
  try {
    const secret = process.env.JWT_SECRET ?? ""
    const parts = token.split(".")
    if (parts.length !== 3) return null
    const [header, body, sig] = parts
    const enc = new TextEncoder()
    const key = await crypto.subtle.importKey(
      "raw", enc.encode(secret),
      { name: "HMAC", hash: "SHA-256" }, false, ["verify"]
    )
    const sigBytes = Uint8Array.from(
      atob(sig.replace(/-/g, "+").replace(/_/g, "/")),
      c => c.charCodeAt(0)
    )
    const valid = await crypto.subtle.verify(
      "HMAC", key, sigBytes,
      enc.encode(header + "." + body)
    )
    if (!valid) return null
    const decoded = JSON.parse(atob(body)) as any
    if (decoded.exp < Math.floor(Date.now() / 1000)) return null
    return { adminId: decoded.adminId, role: decoded.role }
  } catch { return null }
}

export const getDashboardStats = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const session = await verifyAdminSession(ctx, args.token)
    if (!session) throw new Error("Unauthorized")

    const orders = await ctx.db.query("orders").collect();

    let totalRevenue = 0;
    const totalOrders = orders.length;
    const ordersByStatus: Record<string, number> = {};
    const productSales: Record<string, { name: string; quantity: number; revenue: number }> = {};

    const revenueValidStatuses = [
      "processing",
      "shipped",
      "delivered",
    ];

    // Initialize last 6 months
    const now = new Date();
    const last6Months = Array.from({ length: 6 })
      .map((_, i) => {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        return {
          month: d.toLocaleString("default", { month: "short", year: "numeric" }),
          year: d.getFullYear(),
          monthNum: d.getMonth(),
          revenue: 0,
        };
      })
      .reverse();

    for (const order of orders) {
      // Accumulate statuses based on fulfillment status
      ordersByStatus[order.fulfillmentStatus] = (ordersByStatus[order.fulfillmentStatus] || 0) + 1;

      // Accumulate revenue based on proper status and paystack status success
      if (revenueValidStatuses.includes(order.fulfillmentStatus) && order.paystackStatus === "success") {
        totalRevenue += (order.subtotalKobo || 0);

        const orderDate = new Date(order.createdAt || Date.now());
        const orderMonth = last6Months.find(
          (m) =>
            m.year === orderDate.getFullYear() &&
            m.monthNum === orderDate.getMonth()
        );

        if (orderMonth) {
          orderMonth.revenue += (order.subtotalKobo || 0);
        }
      }

      // Track top products if paystack status is success
      if (order.paystackStatus === "success") {
        for (const item of order.items) {
          if (!productSales[item.productId]) {
            productSales[item.productId] = { name: item.name, quantity: 0, revenue: 0 };
          }
          productSales[item.productId].quantity += item.qty;
          productSales[item.productId].revenue += (item.priceKobo * item.qty);
        }
      }
    }

    const topProducts = Object.values(productSales)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 5)
      .map(p => ({
        name: p.name,
        totalQuantity: p.quantity,
        totalRevenue: p.revenue
      }));

    const revenueByMonth = last6Months.map((m) => ({
      month: m.month,
      revenue: m.revenue,
    }));

    return {
      totalRevenue,
      totalOrders,
      ordersByStatus,
      topProducts,
      revenueByMonth,
    };
  },
});
