import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { verifyToken, JWT_SECRET } from "./admins";

export const createCoupon = mutation({
  args: {
    token: v.string(),
    code: v.string(),
    discountPercent: v.number(),
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");
    if (payload.role !== "master") {
      throw new Error("Master admin access required");
    }

    const existing = await ctx.db
      .query("coupons")
      .filter((q) => q.eq(q.field("code"), args.code))
      .first();

    if (existing) {
      throw new Error("Coupon code already exists");
    }

    return await ctx.db.insert("coupons", {
      code: args.code,
      discountPercent: args.discountPercent,
      isActive: true,
      createdAt: Date.now(),
      createdBy: payload.adminId,
      usageCount: 0,
    });
  },
});

export const validateCoupon = query({
  args: { code: v.string() },
  handler: async (ctx, args) => {
    const coupon = await ctx.db
      .query("coupons")
      .filter((q) => q.eq(q.field("code"), args.code))
      .first();

    if (coupon && coupon.isActive) {
      return coupon.discountPercent;
    }
    return null;
  },
});

export const listCoupons = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");
    if (payload.role !== "master") {
      throw new Error("Master admin access required");
    }

    const coupons = await ctx.db.query("coupons").collect();
    return coupons.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  },
});

export const toggleCoupon = mutation({
  args: { token: v.string(), id: v.id("coupons") },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");

    const coupon = await ctx.db.get(args.id);
    if (coupon) {
      await ctx.db.patch(args.id, { isActive: !coupon.isActive });
    }
  },
});
