import { defineSchema, defineTable } from "convex/server"
import { v } from "convex/values"

export default defineSchema({

  products: defineTable({
    name: v.string(),
    slug: v.string(),
    description: v.string(),
    category: v.union(v.literal("perfume"), v.literal("skincare")),
    priceKobo: v.number(),
    priceDisplay: v.string(),
    images: v.array(v.string()),
    stock: v.number(),
    isActive: v.boolean(),
    isFeatured: v.boolean(),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
  .index("by_slug", ["slug"])
  .index("by_category", ["category"])
  .index("by_featured", ["isFeatured"]),

  orders: defineTable({
    trackingCode: v.string(),
    customerName: v.string(),
    customerEmail: v.string(),
    customerPhone: v.string(),
    deliveryAddress: v.string(),
    deliveryCity: v.string(),
    deliveryState: v.string(),
    items: v.array(v.object({
      productId: v.string(),
      name: v.string(),
      qty: v.number(),
      priceKobo: v.number(),
      imageUrl: v.string(),
    })),
    subtotalKobo: v.number(),
    discountKobo: v.number(),
    couponCode: v.optional(v.string()),
    paystackReference: v.string(),
    paystackStatus: v.union(
      v.literal("pending"),
      v.literal("success"),
      v.literal("failed")
    ),
    fulfillmentStatus: v.union(
      v.literal("processing"),
      v.literal("shipped"),
      v.literal("delivered"),
      v.literal("cancelled")
    ),
    createdAt: v.number(),
    updatedAt: v.number(),
  })
  .index("by_trackingCode", ["trackingCode"])
  .index("by_paystackReference", ["paystackReference"])
  .index("by_customerEmail", ["customerEmail"])
  .index("by_fulfillmentStatus", ["fulfillmentStatus"])
  .index("by_paystackStatus", ["paystackStatus"]),

  loginAttempts: defineTable({
    email: v.string(),
    attempts: v.number(),
    lockedUntil: v.number(),
  }).index("by_email", ["email"]),

  admins: defineTable({
    email: v.string(),
    passwordHash: v.string(),
    role: v.union(v.literal("master"), v.literal("sub")),
   isActive: v.optional(v.boolean()),
    createdBy: v.optional(v.string()),
    createdAt: v.number(),
  })
  .index("by_email", ["email"]),

  coupons: defineTable({
    code: v.string(),
    discountPercent: v.number(),
    isActive: v.boolean(),
    usageCount: v.number(),
    createdBy: v.string(),
    createdAt: v.number(),
  })
  .index("by_code", ["code"]),

  reviews: defineTable({
    productId: v.string(),
    trackingCode: v.string(),
    reviewerName: v.string(),
    rating: v.number(),
    body: v.string(),
    status: v.union(
      v.literal("pending"),
      v.literal("approved"),
      v.literal("rejected")
    ),
    createdAt: v.number(),
  })
  .index("by_productId", ["productId"])
  .index("by_status", ["status"])
  .index("by_trackingCode", ["trackingCode"]),

  settings: defineTable({
    key: v.string(),
    value: v.string(),
    updatedBy: v.string(),
    updatedAt: v.number(),
  })
  .index("by_key", ["key"]),

  analyticsEvents: defineTable({
    type: v.union(
      v.literal("page_view"),
      v.literal("add_to_cart"),
      v.literal("checkout_started"),
      v.literal("order_completed")
    ),
    productId: v.optional(v.string()),
    orderId: v.optional(v.string()),
    sessionId: v.string(),
    metadata: v.optional(v.any()),
    createdAt: v.number(),
  })
  .index("by_type", ["type"])
  .index("by_sessionId", ["sessionId"])
  .index("by_createdAt", ["createdAt"]),

  wishlistItems: defineTable({
    sessionId: v.string(),
    productId: v.string(),
    createdAt: v.number(),
  })
  .index("by_sessionId", ["sessionId"]),

})
