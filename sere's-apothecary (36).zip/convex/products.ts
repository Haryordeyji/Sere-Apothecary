import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { verifyToken, JWT_SECRET } from "./admins";

export const getFeaturedProducts = query({
  args: {},
  handler: async (ctx) => {
    try {
      const products = await ctx.db
        .query("products")
        .withIndex("by_featured", (q) => q.eq("isFeatured", true))
        .filter((q) => q.eq(q.field("isActive"), true))
        .order("desc")
        .take(8);
      return products;
    } catch (e: any) {
      console.error("DEBUG getFeaturedProducts ERROR:", e);
      return [];
    }
  },
});

export const listProducts = query({
  args: {
    category: v.optional(v.union(v.literal("perfume"), v.literal("skincare"))),
  },
  handler: async (ctx, args) => {
    try {
      let filteredQuery;
      if (args.category) {
        filteredQuery = ctx.db
          .query("products")
          .withIndex("by_category", (q) => q.eq("category", args.category!))
          .filter((q) => q.eq(q.field("isActive"), true));
      } else {
        filteredQuery = ctx.db
          .query("products")
          .filter((q) => q.eq(q.field("isActive"), true));
      }
      
      const products = await filteredQuery.collect();
      return products.sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0));
    } catch (e: any) {
      console.error("DEBUG listProducts ERROR:", e);
      return [];
    }
  },
});

export const getProduct = query({
  args: { id: v.string() },
  handler: async (ctx, args) => {
    const productId = ctx.db.normalizeId("products", args.id);
    if (!productId) return null;
    return await ctx.db.get(productId);
  },
});

export const createProduct = mutation({
  args: {
    token: v.string(),
    name: v.string(),
    slug: v.string(),
    description: v.string(),
    priceKobo: v.number(),
    priceDisplay: v.string(),
    category: v.union(v.literal("perfume"), v.literal("skincare")),
    images: v.array(v.string()),
    stock: v.number(),
    isActive: v.boolean(),
    isFeatured: v.boolean(),
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");
    const { token, ...rest } = args;

    const now = Date.now();
    return await ctx.db.insert("products", {
      ...rest,
      createdAt: now,
      updatedAt: now,
    });
  },
});

export const updateProduct = mutation({
  args: {
    token: v.string(),
    id: v.string(),
    name: v.optional(v.string()),
    slug: v.optional(v.string()),
    description: v.optional(v.string()),
    priceKobo: v.optional(v.number()),
    priceDisplay: v.optional(v.string()),
    category: v.optional(v.union(v.literal("perfume"), v.literal("skincare"))),
    stock: v.optional(v.number()),
    isActive: v.optional(v.boolean()),
    isFeatured: v.optional(v.boolean()),
    images: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");

    const { id, token, ...updates } = args;
    const productId = ctx.db.normalizeId("products", id);
    if (!productId) throw new Error("Invalid product ID");
    await ctx.db.patch(productId, {
      ...updates,
      updatedAt: Date.now(),
    });
  },
});

export const deleteProduct = mutation({
  args: { token: v.string(), id: v.string() },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");

    const productId = ctx.db.normalizeId("products", args.id);
    if (!productId) throw new Error("Invalid product ID");
    await ctx.db.delete(productId);
  },
});

export const decrementStock = mutation({
  args: {
    productId: v.string(),
    qty: v.number(),
  },
  handler: async (ctx, args) => {
    const productId = ctx.db.normalizeId("products", args.productId);
    if (!productId) return;
    const product = await ctx.db.get(productId);
    if (!product) return;
    const newStock = Math.max(0, product.stock - args.qty);
    await ctx.db.patch(productId, { stock: newStock, updatedAt: Date.now() });
  },
});
