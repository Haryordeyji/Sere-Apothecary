import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { verifyToken, JWT_SECRET } from "./admins";

export const submitReview = mutation({
  args: {
    productId: v.string(),
    trackingCode: v.string(),
    reviewerName: v.string(),
    rating: v.number(),
    body: v.string(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("reviews", {
      ...args,
      status: "pending",
      createdAt: Date.now(),
    });
  },
});

export const listApprovedReviews = query({
  args: { productId: v.string() },
  handler: async (ctx, args) => {
    const reviews = await ctx.db
      .query("reviews")
      .withIndex("by_productId", (q) => q.eq("productId", args.productId))
      .filter((q) => q.eq(q.field("status"), "approved"))
      .collect();

    return reviews.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  },
});

export const updateReviewStatus = mutation({
  args: {
    token: v.string(),
    id: v.string(),
    status: v.union(v.literal("approved"), v.literal("rejected"))
  },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");

    const reviewId = ctx.db.normalizeId("reviews", args.id);
    if (!reviewId) throw new Error("Invalid review ID");
    await ctx.db.patch(reviewId, { status: args.status });
  },
});

export const deleteReview = mutation({
  args: { token: v.string(), id: v.string() },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");

    const reviewId = ctx.db.normalizeId("reviews", args.id);
    if (!reviewId) throw new Error("Invalid review ID");
    await ctx.db.delete(reviewId);
  },
});

export const listAllReviews = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const payload = await verifyToken(args.token, JWT_SECRET);
    if (!payload) throw new Error("Unauthorized");

    return await ctx.db
      .query('reviews')
      .order('desc')
      .collect()
  },
});
