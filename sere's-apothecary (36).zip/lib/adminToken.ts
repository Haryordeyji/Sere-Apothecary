// lib/adminToken.ts
// Token is stored in httpOnly cookie only.
// Read it by calling getAdminSession() once per page in useEffect.

export async function getAdminSession(): Promise<{
  email: string
  role: 'master' | 'sub'
  token: string
} | null> {
  try {
    if (typeof window === 'undefined') return null
    const res = await fetch('/api/admin/session')
    const data = await res.json()
    if (data?.token && data?.role && data?.email) return data
    return null
  } catch {
    return null
  }
}

// Sync helper — only use this AFTER you already have the session
// from an awaited getAdminSession() call stored in component state.
// Do NOT call this at render time — it will always return ''.
export function getAdminToken(): string {
  console.warn(
    'getAdminToken() is deprecated. Use getAdminSession() in useEffect instead.'
  )
  return ''
}
