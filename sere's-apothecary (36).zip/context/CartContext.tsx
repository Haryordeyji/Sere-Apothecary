'use client'

import React, { createContext, useContext, useState, useMemo } from 'react'
import toast from 'react-hot-toast'

export interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  imageUrl: string
  category: string
}

interface CartContextType {
  items: CartItem[]
  addToCart: (item: Omit<CartItem, 'quantity'> & { quantity?: number }) => void
  removeFromCart: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  applyDiscount: (percent: number) => void
  removeDiscount: () => void
  subtotal: number
  discountAmount: number
  total: number
  itemCount: number
  discountPercent: number
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [discountPercent, setDiscountPercent] = useState(0)

  const addToCart = (newItem: Omit<CartItem, 'quantity'> & { quantity?: number }) => {
    setItems((prevItems) => {
      const existingItem = prevItems.find((item) => item.id === newItem.id)
      const quantityToAdd = newItem.quantity || 1

      if (existingItem) {
        return prevItems.map((item) =>
          item.id === newItem.id
            ? { ...item, quantity: Math.min(10, item.quantity + quantityToAdd) }
            : item
        )
      }
      return [...prevItems, { ...newItem, quantity: Math.min(10, quantityToAdd) }]
    })
    toast.success('Added to cart')
  }

  const removeFromCart = (id: string) => {
    setItems((prevItems) => prevItems.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id)
      return
    }
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, quantity: Math.min(10, quantity) } : item
      )
    )
  }

  const clearCart = () => {
    setItems([])
    setDiscountPercent(0)
  }

  const applyDiscount = (percent: number) => {
    setDiscountPercent(percent)
  }

  const removeDiscount = () => {
    setDiscountPercent(0)
  }

  const subtotal = useMemo(() => {
    return items.reduce((acc, item) => acc + item.price * item.quantity, 0)
  }, [items])

  const discountAmount = useMemo(() => {
    return subtotal * (discountPercent / 100)
  }, [subtotal, discountPercent])

  const total = useMemo(() => {
    return subtotal - discountAmount
  }, [subtotal, discountAmount])

  const itemCount = useMemo(() => {
    return items.reduce((acc, item) => acc + item.quantity, 0)
  }, [items])

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        applyDiscount,
        removeDiscount,
        subtotal,
        discountAmount,
        total,
        itemCount,
        discountPercent
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider')
  }
  return context
}
