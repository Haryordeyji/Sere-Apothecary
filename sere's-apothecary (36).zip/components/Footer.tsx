import Link from 'next/link'
import { MessageCircle, Phone } from 'lucide-react'
import NewsletterForm from './NewsletterForm'

export default function Footer() {
  return (
    <footer className="bg-brown-deep text-cream/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-8">

        {/* Four columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">

          {/* Column 1 — Brand */}
          <div>
            <p className="font-accent text-gold tracking-[0.25em] text-sm uppercase mb-4">
              Sere&apos;s Apothecary
            </p>
            <p className="font-body text-sm leading-relaxed text-cream/50 mb-6">
              Curating the world&apos;s finest fragrances and skincare rituals.
              Premium beauty, delivered from Benin City, Nigeria.
            </p>
            <p className="font-body text-xs text-gold/60 leading-relaxed border-l-2 border-gold/30 pl-3">
              All prices shown are product costs only. Delivery fees are
              communicated separately after order confirmation.
            </p>
          </div>

          {/* Column 2 — Navigation */}
          <div>
            <p className="font-accent text-gold tracking-widest text-xs uppercase mb-6">
              Explore
            </p>
            <nav className="flex flex-col gap-3">
              {[
                { label: 'Home', href: '/' },
                { label: 'Perfumes', href: '/perfumes' },
                { label: 'Skincare', href: '/skincare' },
                { label: 'Track Your Order', href: '/track' },
              ].map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="gold-underline font-body text-sm text-cream/50 hover:text-gold transition-colors duration-200 w-fit"
                >
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>

          {/* Column 3 — Contact */}
          <div>
            <p className="font-accent text-gold tracking-widest text-xs uppercase mb-6">
              Get in Touch
            </p>
            <div className="flex flex-col gap-4">
              <a
                href="https://wa.link/q4durx"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 font-body text-sm text-cream/50 hover:text-gold transition-colors duration-200 group"
              >
                <MessageCircle
                  size={16}
                  className="text-gold/60 group-hover:text-gold transition-colors shrink-0"
                />
                Chat on WhatsApp
              </a>
              <a
                href="tel:+2347044579258"
                className="flex items-center gap-3 font-body text-sm text-cream/50 hover:text-gold transition-colors duration-200 group"
              >
                <Phone
                  size={16}
                  className="text-gold/60 group-hover:text-gold transition-colors shrink-0"
                />
                +234 704 457 9258
              </a>
              <p className="font-body text-xs text-cream/30 mt-1">
                Benin City, Nigeria. Online orders only.
              </p>
            </div>
          </div>

          {/* Column 4 — Newsletter */}
          <div>
            <p className="font-accent text-gold tracking-widest text-xs uppercase mb-6">
              Newsletter
            </p>
            <p className="font-body text-sm leading-relaxed text-cream/50 mb-4">
              Subscribe to receive updates, access to exclusive deals, and more.
            </p>
            <NewsletterForm />
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-gold/10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-body text-xs text-cream/30">
            © 2026 Sere&apos;s Apothecary. All rights reserved.
          </p>
          {/* Discreet staff portal — nearly invisible by design */}
          <Link
            href="/admin/login"
            className="font-body text-[11px] text-cream/[0.15] hover:text-cream/25 transition-colors duration-300"
            tabIndex={-1}
          >
            Staff Portal
          </Link>
        </div>

      </div>
    </footer>
  )
}