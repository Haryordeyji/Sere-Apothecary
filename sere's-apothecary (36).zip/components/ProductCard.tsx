"use client";

import Image from "next/image";
import Link from "next/link";
import { Heart } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useWishlist } from "@/context/WishlistContext";

interface ProductCardProps {
  product: {
    _id: string;
    name: string;
    priceKobo?: number;
    price?: number; // allow both for flexibility
    images?: string[];
    imageUrl?: string; // allow both
    category: string;
  };
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  const { isInWishlist, addToWishlist, removeFromWishlist } = useWishlist();

  const price = product.priceKobo ? product.priceKobo / 100 : (product.price || 0);
  const imageUrl = product.images?.[0] || product.imageUrl || null;

  const handleWishlistToggle = () => {
    if (isInWishlist(product._id)) {
      removeFromWishlist(product._id);
    } else {
      addToWishlist({
        id: product._id,
        name: product.name,
        price,
        imageUrl: imageUrl || "",
        category: product.category,
      });
    }
  };

  const formatPrice = (amount: number) => {
    return `₦${amount.toLocaleString("en-NG", { minimumFractionDigits: 2 })}`;
  };

  return (
    <div className="card-luxury bg-cream p-4 relative group flex flex-col h-full border border-brown/5 hover:border-gold/30 transition-colors">
      <div className="relative aspect-square w-full bg-cream-warm rounded-sm overflow-hidden mb-4">
        {imageUrl ? (
          <Image
            src={imageUrl}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 50vw, 25vw"
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="absolute inset-0 bg-cream-warm flex items-center justify-center">
            <span className="font-accent text-xs text-brown/20 tracking-widest uppercase">No Image</span>
          </div>
        )}
        <div className="absolute top-2 left-2 bg-cream/90 backdrop-blur-sm px-2 py-1">
          <span className="font-accent text-[10px] tracking-wider text-brown uppercase">
            {product.category || 'product'}
          </span>
        </div>
        <button
          onClick={handleWishlistToggle}
          className="absolute top-2 right-2 p-2 bg-cream/90 backdrop-blur-sm rounded-full text-brown/50 hover:text-brown transition-colors"
        >
          <Heart
            size={16}
            className={
              isInWishlist(product._id) ? "fill-brown text-brown" : ""
            }
          />
        </button>
      </div>

      <div className="flex-1 flex flex-col">
        <Link href={`/product/${product._id}`}>
          <h3 className="font-display text-brown text-lg leading-snug hover:text-gold transition-colors">
            {product.name}
          </h3>
        </Link>

        <p className="font-body text-gold mt-auto mb-3 text-lg">
          {price > 0 ? formatPrice(price) : 'Price on request'}
        </p>

        <div className="pt-3 border-t border-gold/10">
          <button
            onClick={() =>
              addToCart({
                id: product._id,
                name: product.name,
                price,
                imageUrl: imageUrl || "",
                category: product.category,
                quantity: 1,
              })
            }
            className="btn-outline-gold w-full text-sm py-2"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
}
