'use client'

export default function ProductGridSkeleton({ count = 8 }: { count?: number }) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="card-luxury bg-cream p-4 flex flex-col h-full animate-pulse border border-gold/10">
          <div className="aspect-square w-full bg-brown/5 rounded-sm mb-4" />
          <div className="h-5 bg-brown/5 rounded w-3/4 mb-2" />
          <div className="h-4 bg-brown/5 rounded w-1/3 mt-1 mb-4" />
          <div className="mt-auto pt-3 border-t border-gold/5">
            <div className="h-9 bg-brown/5 rounded w-full" />
          </div>
        </div>
      ))}
    </>
  )
}
