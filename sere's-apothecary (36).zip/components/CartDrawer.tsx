'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { X, ShoppingBag, Trash2, Plus, Minus, Tag, Check } from 'lucide-react'
import Image from 'next/image'
import { useQuery } from 'convex/react'
import { api } from '@/convex/_generated/api'
import { useCart } from '@/context/CartContext'

interface CartDrawerProps {
  isOpen: boolean
  onClose: () => void
}

export default function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const router = useRouter()
  const {
    items,
    removeFromCart,
    updateQuantity,
    subtotal,
    discountAmount,
    total,
    discountPercent,
    applyDiscount,
    removeDiscount,
  } = useCart()

  const [couponInput, setCouponInput] = useState('')
  const [appliedCode, setAppliedCode] = useState('')
  const [couponError, setCouponError] = useState('')
  const [isValidating, setIsValidating] = useState(false)
  const [lookupCode, setLookupCode] = useState('')

  // Query runs whenever lookupCode changes
  // Returns discount percent if valid, null if invalid
  const couponResult = useQuery(
    api.coupons.validateCoupon,
    lookupCode ? { code: lookupCode } : 'skip'
  )

  // Watch for couponResult to resolve after user clicks Apply
  // couponResult === undefined means query is still loading
  // couponResult === null means invalid/inactive coupon
  // couponResult === number means valid — that's the discount %
  const handleApplyCoupon = () => {
    const code = couponInput.trim().toUpperCase()
    if (!code) return
    if (discountPercent > 0) return

    setCouponError('')
    setIsValidating(true)
    // Trigger the query by setting lookupCode
    setLookupCode(code)
  }

  // React to query result changes
  // This effect-like pattern uses the render cycle instead of useEffect
  if (isValidating && lookupCode && couponResult !== undefined) {
    if (couponResult !== null && typeof couponResult === 'number') {
      // Valid coupon
      applyDiscount(couponResult)
      setAppliedCode(lookupCode)
      setIsValidating(false)
      setCouponInput('')
    } else if (couponResult === null) {
      // Invalid or inactive coupon
      setCouponError('Invalid or expired coupon code.')
      setIsValidating(false)
      setLookupCode('')
    }
  }

  const handleRemoveCoupon = () => {
    removeDiscount()
    setCouponInput('')
    setAppliedCode('')
    setCouponError('')
    setLookupCode('')
    setIsValidating(false)
  }

  const handleCheckout = () => {
    onClose()
    router.push('/checkout')
  }

  const formatPrice = (amount: number) =>
    `₦${amount.toLocaleString('en-NG', { minimumFractionDigits: 2 })}`

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 z-50 bg-black/50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div
            className="fixed right-0 top-0 h-full w-full max-w-md z-50 bg-cream-warm flex flex-col shadow-luxury"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.3 }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-gold/20">
              <h2 className="font-display text-xl text-brown">Your Cart</h2>
              <button
                onClick={onClose}
                className="text-brown/40 hover:text-brown transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {items.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center px-6 gap-4">
                <ShoppingBag size={48} className="text-brown/20" />
                <p className="font-display text-xl text-brown/50">
                  Your cart is empty
                </p>
                <button onClick={onClose} className="btn-outline-gold mt-2">
                  Continue Shopping
                </button>
              </div>
            ) : (
              <>
                {/* Items list */}
                <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
                  {items.map((item) => (
                    <div
                      key={item.id}
                      className="flex gap-3 pb-4 border-b border-gold/10 last:border-0"
                    >
                      {/* Image */}
                      <div className="relative w-16 h-16 shrink-0 bg-cream rounded overflow-hidden">
                        <Image
                          src={item.imageUrl || '/placeholder-product.jpg'}
                          alt={item.name}
                          fill
                          className="object-cover"
                          sizes="64px"
                        />
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <p className="font-display text-brown text-sm leading-snug truncate">
                          {item.name}
                        </p>
                        <p className="font-body text-gold text-sm mt-0.5">
                          {formatPrice(item.price)}
                        </p>

                        {/* Quantity controls */}
                        <div className="flex items-center gap-2 mt-2">
                          <button
                            onClick={() =>
                              updateQuantity(item.id, item.quantity - 1)
                            }
                            className="w-6 h-6 border border-brown/20 rounded flex items-center justify-center text-brown/60 hover:border-gold hover:text-gold transition-colors"
                          >
                            <Minus size={12} />
                          </button>
                          <span className="font-body text-sm text-brown w-6 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() =>
                              updateQuantity(item.id, item.quantity + 1)
                            }
                            disabled={item.quantity >= 10}
                            className="w-6 h-6 border border-brown/20 rounded flex items-center justify-center text-brown/60 hover:border-gold hover:text-gold transition-colors disabled:opacity-30"
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                      </div>

                      {/* Line total + remove */}
                      <div className="flex flex-col items-end justify-between shrink-0">
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-brown/20 hover:text-red-400 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                        <p className="font-body text-sm text-brown/70">
                          {formatPrice(item.price * item.quantity)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Bottom section */}
                <div className="px-6 py-5 border-t border-gold/20 space-y-4 bg-cream-warm">

                  {/* Coupon */}
                  {discountPercent > 0 ? (
                    <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded px-3 py-2">
                      <div className="flex items-center gap-2">
                        <Check size={14} className="text-green-600" />
                        <span className="font-body text-sm text-green-700">
                          {appliedCode} — {discountPercent}% off
                        </span>
                      </div>
                      <button
                        onClick={handleRemoveCoupon}
                        className="text-xs text-green-600 hover:text-red-500 transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      <div className="flex gap-2">
                        <div className="relative flex-1">
                          <Tag
                            size={14}
                            className="absolute left-3 top-1/2 -translate-y-1/2 text-brown/30"
                          />
                          <input
                            type="text"
                            value={couponInput}
                            onChange={(e) => {
                              setCouponInput(e.target.value.toUpperCase())
                              setCouponError('')
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleApplyCoupon()
                            }}
                            placeholder="Coupon code"
                            className="w-full pl-8 pr-3 py-2 border border-brown/20 bg-white font-body text-sm text-brown placeholder:text-brown/30 focus:outline-none focus:border-gold transition-colors"
                          />
                        </div>
                        <button
                          onClick={handleApplyCoupon}
                          disabled={isValidating || !couponInput.trim()}
                          style={{
                            backgroundColor: '#2C1810',
                            color: '#C9A84C',
                            padding: '8px 16px',
                            fontFamily: 'Georgia, serif',
                            letterSpacing: '0.1em',
                            fontSize: '11px',
                            textTransform: 'uppercase',
                            border: 'none',
                            cursor: isValidating || !couponInput.trim()
                              ? 'not-allowed'
                              : 'pointer',
                            opacity: isValidating || !couponInput.trim()
                              ? 0.5
                              : 1,
                          }}
                        >
                          {isValidating ? '...' : 'Apply'}
                        </button>
                      </div>

                      {couponError && (
                        <p className="font-body text-xs text-red-500">
                          {couponError}
                        </p>
                      )}

                      {isValidating && (
                        <p className="font-body text-xs text-brown/40">
                          Checking coupon...
                        </p>
                      )}
                    </div>
                  )}

                  {/* Totals */}
                  <div className="space-y-1">
                    {discountAmount > 0 && (
                      <>
                        <div className="flex justify-between font-body text-sm text-brown/60">
                          <span>Subtotal</span>
                          <span className="line-through">
                            {formatPrice(subtotal)}
                          </span>
                        </div>
                        <div className="flex justify-between font-body text-sm text-green-600">
                          <span>Discount ({discountPercent}%)</span>
                          <span>-{formatPrice(discountAmount)}</span>
                        </div>
                      </>
                    )}
                    <div className="flex justify-between font-display text-lg text-brown pt-1">
                      <span>Total</span>
                      <span className="text-gold">{formatPrice(total)}</span>
                    </div>
                  </div>

                  {/* Disclaimer */}
                  <div className="border-l-2 border-gold/40 bg-amber-50/60 px-3 py-2">
                    <p className="font-body text-xs text-amber-800 leading-relaxed">
                      <strong>Note:</strong> Price shown is product cost only.
                      Delivery fee is <strong>NOT included</strong> and will be
                      communicated separately.
                    </p>
                  </div>

                  {/* CTA */}
                  <button
                    onClick={handleCheckout}
                    style={{
                      backgroundColor: '#C9A84C',
                      color: '#2C1810',
                      width: '100%',
                      padding: '14px 24px',
                      fontFamily: 'Georgia, serif',
                      letterSpacing: '0.2em',
                      textTransform: 'uppercase',
                      fontSize: '13px',
                      fontWeight: '600',
                      border: 'none',
                      cursor: 'pointer',
                      display: 'block',
                    }}
                  >
                    Proceed to Checkout
                  </button>
                </div>
              </>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}