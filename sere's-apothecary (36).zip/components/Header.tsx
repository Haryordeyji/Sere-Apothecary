'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { motion, AnimatePresence, useScroll } from 'framer-motion'
import { ShoppingBag, Heart, Menu, X } from 'lucide-react'
import { useCart } from '@/context/CartContext'
import { useWishlist } from '@/context/WishlistContext'

interface HeaderProps {
  onCartOpen: () => void
}

const navLinks = [
  { label: 'Home', href: '/' },
  { label: 'Perfumes', href: '/perfumes' },
  { label: 'Skincare', href: '/skincare' },
]

export default function Header({ onCartOpen }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const pathname = usePathname()
  const { itemCount } = useCart()
  const { items: wishlistItems } = useWishlist()

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Close mobile menu on route change
  useEffect(() => setMobileOpen(false), [pathname])

  return (
    <>
      <motion.header
        className="fixed top-0 left-0 right-0 z-50"
        animate={{
          backgroundColor: scrolled ? '#2C1810' : 'rgba(0,0,0,0)',
          boxShadow: scrolled
            ? '0 1px 0 rgba(201,168,76,0.15)'
            : '0 0 0 transparent',
        }}
        transition={{ duration: 0.3 }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">

            {/* Desktop nav — left */}
            <nav className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`gold-underline font-body text-sm tracking-widest uppercase transition-colors duration-200 ${
                    pathname === link.href
                      ? 'text-gold'
                      : 'text-cream/70 hover:text-cream'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* Mobile — hamburger */}
            <button
              className="lg:hidden text-cream/80 hover:text-gold transition-colors"
              onClick={() => setMobileOpen(true)}
              aria-label="Open menu"
            >
              <Menu size={22} />
            </button>

            {/* Brand name — center */}
            <Link
              href="/"
              className="absolute left-1/2 -translate-x-1/2 font-accent text-gold tracking-[0.25em] text-xs sm:text-sm uppercase whitespace-nowrap"
            >
              Sere&apos;s Apothecary
            </Link>

            {/* Icons — right */}
            <div className="flex items-center gap-4">
              {/* Wishlist */}
              <Link
                href="/wishlist"
                className="relative text-cream/70 hover:text-gold transition-colors block"
                aria-label="Wishlist"
              >
                <Heart size={20} />
                {wishlistItems.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-gold text-brown text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center leading-none">
                    {wishlistItems.length}
                  </span>
                )}
              </Link>

              {/* Cart */}
              <button
                onClick={onCartOpen}
                className="relative text-cream/70 hover:text-gold transition-colors"
                aria-label="Open cart"
              >
                <ShoppingBag size={20} />
                {itemCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-gold text-brown text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center leading-none">
                    {itemCount > 9 ? '9+' : itemCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Mobile menu overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              className="fixed inset-0 z-40 bg-black/60"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
            />

            {/* Drawer */}
            <motion.div
              className="fixed top-0 left-0 h-full w-72 z-50 bg-brown-deep flex flex-col"
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
            >
              {/* Close */}
              <div className="flex items-center justify-between px-6 py-5 border-b border-gold/20">
                <span className="font-accent text-gold tracking-widest text-xs uppercase">
                  Menu
                </span>
                <button
                  onClick={() => setMobileOpen(false)}
                  className="text-cream/60 hover:text-gold transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Links */}
              <nav className="flex flex-col gap-1 px-6 py-8">
                {navLinks.map((link, i) => (
                  <motion.div
                    key={link.href}
                    initial={{ opacity: 0, x: -16 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.07 }}
                  >
                    <Link
                      href={link.href}
                      className={`block py-3 font-display text-2xl font-light transition-colors duration-200 ${
                        pathname === link.href
                          ? 'text-gold'
                          : 'text-cream/70 hover:text-gold'
                      }`}
                    >
                      {link.label}
                    </Link>
                  </motion.div>
                ))}
              </nav>

              {/* Contact at bottom */}
              <div className="mt-auto px-6 py-6 border-t border-gold/20">
                <p className="font-body text-xs text-cream/30 tracking-widest uppercase mb-3">
                  Support
                </p>
                <a
                  href="https://wa.link/q4durx"
                  className="block font-body text-sm text-cream/60 hover:text-gold transition-colors mb-2"
                >
                  WhatsApp Us
                </a>
                <a
                  href="tel:+2347044579258"
                  className="block font-body text-sm text-cream/60 hover:text-gold transition-colors"
                >
                  +234 704 457 9258
                </a>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}