'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'

export default function NewsletterForm() {
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState<
    'idle' | 'loading' | 'success' | 'error'
  >('idle')
  const [errorMsg, setErrorMsg] = useState('')

  const handleSubmit = async (
    e: React.FormEvent
  ) => {
    e.preventDefault()
    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('Please enter a valid email.')
      setStatus('error')
      return
    }

    setStatus('loading')
    setErrorMsg('')

    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json' 
        },
        body: JSON.stringify({ 
          email: email.trim() 
        }),
      })

      const data = await res.json()

      if (data.success) {
        setStatus('success')
        setEmail('')
      } else {
        setStatus('error')
        setErrorMsg(
          data.error || 
          'Something went wrong. Please try again.'
        )
      }
    } catch {
      setStatus('error')
      setErrorMsg(
        'Something went wrong. Please try again.'
      )
    }
  }

  if (status === 'success') {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        style={{
          border: '1px solid rgba(201,168,76,0.3)',
          backgroundColor: 'rgba(201,168,76,0.08)',
          padding: '20px 24px',
          textAlign: 'center',
        }}
      >
        <p style={{
          fontFamily: 'Georgia, serif',
          color: '#C9A84C',
          fontSize: '18px',
          marginBottom: '6px',
        }}>
          Welcome to the circle ✦
        </p>
        <p style={{
          fontFamily: 'Inter, sans-serif',
          color: 'rgba(245,240,232,0.5)',
          fontSize: '13px',
        }}>
          Check your inbox for a message from us.
        </p>
      </motion.div>
    )
  }

  return (
    <form 
      onSubmit={handleSubmit} 
      className="flex flex-col sm:flex-row gap-3"
    >
      <input
        type="email"
        value={email}
        onChange={(e) => {
          setEmail(e.target.value)
          setStatus('idle')
          setErrorMsg('')
        }}
        placeholder="Your email address"
        style={{
          flex: 1,
          backgroundColor: 'rgba(245,240,232,0.05)',
          border: '1px solid rgba(201,168,76,0.2)',
          color: '#F5F0E8',
          padding: '12px 20px',
          fontFamily: 'Inter, sans-serif',
          fontSize: '14px',
          outline: 'none',
        }}
      />
      <button
        type="submit"
        disabled={status === 'loading'}
        style={{
          backgroundColor: 
            status === 'loading' 
              ? 'rgba(201,168,76,0.5)' 
              : '#C9A84C',
          color: '#2C1810',
          padding: '12px 28px',
          fontFamily: 'Georgia, serif',
          letterSpacing: '0.2em',
          fontSize: '12px',
          textTransform: 'uppercase',
          fontWeight: '600',
          border: 'none',
          cursor: status === 'loading' 
            ? 'not-allowed' 
            : 'pointer',
          whiteSpace: 'nowrap',
        }}
      >
        {status === 'loading' 
          ? 'Subscribing...' 
          : 'Subscribe'}
      </button>
      {status === 'error' && errorMsg && (
        <p style={{
          color: '#f87171',
          fontSize: '12px',
          fontFamily: 'Inter, sans-serif',
          marginTop: '4px',
          width: '100%',
        }}>
          {errorMsg}
        </p>
      )}
    </form>
  )
}
